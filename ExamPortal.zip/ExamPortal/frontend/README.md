# ExamPortal Frontend

A modern, responsive Angular frontend for the Online Exam & Proctoring System.

## 🚀 Features

### 🔐 Authentication & Authorization
- **JWT-based authentication** with automatic token management
- **Role-based routing** (Admin, Instructor, Student)
- **Secure login/registration** with form validation
- **Auto-logout** on token expiration

### 📱 Responsive Design
- **Mobile-first approach** with responsive layouts
- **Professional UI/UX** with smooth animations
- **Dark/Light theme** toggle support
- **Accessibility features** (ARIA labels, keyboard navigation)

### 🎯 Student Features
- **Exam interface** with timer and auto-submit
- **Real-time proctoring** with webcam monitoring
- **Question navigation** with progress tracking
- **Results dashboard** with performance analytics
- **Violation alerts** and cheating detection

### 👨‍🏫 Instructor Features (Coming Soon)
- **Exam creation** and management
- **Question bank** management
- **Student assignment** and monitoring
- **Results analysis** and reporting

### 👨‍💼 Admin Features (Coming Soon)
- **User management** across all roles
- **System analytics** and monitoring
- **Audit logs** and security reports
- **System configuration**

### 🎥 Proctoring Integration
- **WebRTC camera access** with permission handling
- **AI-ready monitoring** with snapshot capture
- **Real-time violation detection**
- **Automated cheating alerts**

## 🛠️ Technology Stack

- **Framework**: Angular 17+ (Standalone Components)
- **Styling**: SCSS with CSS Custom Properties
- **Icons**: Material Icons
- **Charts**: Chart.js with ng2-charts
- **HTTP**: Angular HttpClient with Interceptors
- **Routing**: Angular Router with Guards
- **Forms**: Reactive Forms with Validation

## 📦 Installation

### Prerequisites
- Node.js 18+ and npm
- Angular CLI 17+

### Setup
```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build
```

## 🏗️ Project Structure

```
src/
├── app/
│   ├── components/          # Feature components
│   │   ├── auth/           # Authentication components
│   │   ├── dashboard/      # Role-based dashboards
│   │   ├── exam/           # Exam interface
│   │   └── shared/         # Reusable components
│   ├── services/           # Business logic services
│   ├── guards/             # Route protection
│   ├── interceptors/       # HTTP interceptors
│   ├── models/             # TypeScript interfaces
│   └── shared/             # Shared utilities
├── assets/                 # Static assets
├── environments/           # Environment configs
└── styles.scss            # Global styles
```

## 🎨 Design System

### Color Palette
- **Primary**: #6366f1 (Indigo)
- **Secondary**: #10b981 (Emerald)
- **Success**: #22c55e (Green)
- **Warning**: #f59e0b (Amber)
- **Error**: #ef4444 (Red)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Weights**: 300, 400, 500, 600, 700

### Spacing System
- **Base Unit**: 0.25rem (4px)
- **Scale**: xs(4px), sm(8px), md(16px), lg(24px), xl(32px), 2xl(48px)

### Components
- **Cards**: Elevated surfaces with shadows
- **Buttons**: Multiple variants with hover effects
- **Forms**: Consistent styling with validation states
- **Animations**: Smooth transitions and micro-interactions

## 🔒 Security Features

### Authentication
- **JWT token storage** in localStorage
- **Automatic token refresh** handling
- **Secure HTTP interceptors**
- **Route protection** with guards

### Proctoring Security
- **Camera permission** validation
- **Secure image capture** and transmission
- **Real-time monitoring** with AI integration
- **Violation logging** and reporting

## 📱 Responsive Breakpoints

```scss
// Mobile First Approach
@media (max-width: 480px)  // Mobile
@media (max-width: 768px)  // Tablet
@media (max-width: 1024px) // Desktop
@media (min-width: 1200px) // Large Desktop
```

## 🎯 Key Components

### Authentication Flow
1. **Login Component** - JWT authentication
2. **Register Component** - User registration
3. **Auth Guard** - Route protection
4. **Auth Interceptor** - Token injection

### Exam Interface
1. **Exam Component** - Main exam interface
2. **Timer Service** - Countdown and auto-submit
3. **Proctoring Service** - Camera monitoring
4. **Question Navigation** - Progress tracking

### Dashboard System
1. **Role-based Dashboards** - Admin/Instructor/Student
2. **Performance Analytics** - Charts and statistics
3. **Results Display** - Detailed score analysis
4. **Theme Toggle** - Dark/Light mode

## 🔧 Configuration

### Environment Variables
```typescript
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api'
};
```

### API Integration
- **Base URL**: Configurable via environment
- **Interceptors**: Automatic token handling
- **Error Handling**: Global error management
- **Loading States**: User feedback during requests

## 🚀 Development

### Running the Application
```bash
# Development server
ng serve

# Production build
ng build --prod

# Run tests
ng test

# Lint code
ng lint
```

### Code Standards
- **TypeScript Strict Mode** enabled
- **ESLint** for code quality
- **Prettier** for code formatting
- **Component-based Architecture**

## 📊 Performance

### Optimization Features
- **Lazy Loading** for route modules
- **OnPush Change Detection** where applicable
- **Tree Shaking** for smaller bundles
- **Service Workers** ready for PWA

### Bundle Analysis
```bash
# Analyze bundle size
ng build --stats-json
npx webpack-bundle-analyzer dist/stats.json
```

## 🧪 Testing

### Unit Testing
- **Jasmine** testing framework
- **Karma** test runner
- **Component testing** with TestBed
- **Service testing** with mocks

### E2E Testing
- **Cypress** for end-to-end testing
- **Page Object Model** pattern
- **API mocking** for isolated tests

## 🌐 Browser Support

- **Chrome** 90+
- **Firefox** 88+
- **Safari** 14+
- **Edge** 90+

## 📈 Future Enhancements

### Planned Features
- **Real-time notifications** with WebSocket
- **Advanced analytics** with interactive charts
- **Mobile app** with Ionic/Capacitor
- **Offline support** with service workers
- **Multi-language** internationalization

### Technical Improvements
- **State management** with NgRx
- **Component library** with Storybook
- **Advanced testing** with Playwright
- **Performance monitoring** with Web Vitals

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Follow coding standards
4. Write tests for new features
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Contact the development team

---

Built with ❤️ using Angular 17+ and modern web technologies.