import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StudentProgressService, StudentProgress } from '../../services/student-progress.service';
import { NavbarComponent } from '../shared/navbar.component';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="progress-container fade-in">
      <div class="progress-header">
        <div class="header-content">
          <div class="header-text">
            <h1>Student Progress Tracking</h1>
            <p>Monitor and analyze student performance across all exams</p>
          </div>
          <div class="header-stats">
            <div class="stat-item">
              <div class="stat-number">{{ progressSummary.totalStudents }}</div>
              <div class="stat-label">Total Students</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ progressSummary.averageCompletion }}%</div>
              <div class="stat-label">Avg Completion</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ progressSummary.averageScore }}%</div>
              <div class="stat-label">Avg Score</div>
            </div>
          </div>
        </div>
      </div>

      <div class="progress-content">
        <div class="filters-section card">
          <div class="section-header">
            <h2>
              <span class="material-icons">filter_list</span>
              Filters & Analytics
            </h2>
          </div>
          <div class="filters-grid">
            <div class="filter-item">
              <label>Sort by:</label>
              <select (change)="sortStudents($event)" class="form-input">
                <option value="name">Name</option>
                <option value="averageScore">Average Score</option>
                <option value="completedExams">Completed Exams</option>
                <option value="lastExamDate">Last Exam Date</option>
              </select>
            </div>
            <div class="filter-item">
              <label>Performance:</label>
              <select (change)="filterByPerformance($event)" class="form-input">
                <option value="all">All Students</option>
                <option value="excellent">Excellent (90%+)</option>
                <option value="good">Good (80-89%)</option>
                <option value="average">Average (70-79%)</option>
                <option value="poor">Below Average (<70%)</option>
              </select>
            </div>
          </div>
        </div>

        <div class="students-section card">
          <div class="section-header">
            <h2>
              <span class="material-icons">people</span>
              Student Performance Overview
            </h2>
            <div class="view-toggle">
              <button 
                class="btn btn-sm" 
                [class.btn-primary]="viewMode === 'grid'"
                [class.btn-secondary]="viewMode !== 'grid'"
                (click)="viewMode = 'grid'">
                <span class="material-icons">grid_view</span>
              </button>
              <button 
                class="btn btn-sm" 
                [class.btn-primary]="viewMode === 'table'"
                [class.btn-secondary]="viewMode !== 'table'"
                (click)="viewMode = 'table'">
                <span class="material-icons">table_rows</span>
              </button>
            </div>
          </div>

          <!-- Grid View -->
          <div *ngIf="viewMode === 'grid'" class="students-grid">
            <div *ngFor="let student of filteredStudents" class="student-card card">
              <div class="student-header">
                <div class="student-avatar">
                  <span class="material-icons">person</span>
                </div>
                <div class="student-info">
                  <h3>{{ student.studentName }}</h3>
                  <p>{{ student.email }}</p>
                </div>
                <div class="performance-badge" [class]="getPerformanceClass(student.averageScore)">
                  {{ student.averageScore }}%
                </div>
              </div>

              <div class="student-stats">
                <div class="stat-row">
                  <span class="stat-label">Completed Exams:</span>
                  <span class="stat-value">{{ student.completedExams }}/{{ student.totalExams }}</span>
                </div>
                <div class="stat-row">
                  <span class="stat-label">Highest Score:</span>
                  <span class="stat-value">{{ student.highestScore }}%</span>
                </div>
                <div class="stat-row">
                  <span class="stat-label">Time Spent:</span>
                  <span class="stat-value">{{ student.totalTimeSpent }} min</span>
                </div>
                <div class="stat-row">
                  <span class="stat-label">Last Exam:</span>
                  <span class="stat-value">{{ formatDate(student.lastExamDate) }}</span>
                </div>
              </div>

              <div class="progress-bar">
                <div class="progress-fill" [style.width.%]="(student.completedExams / student.totalExams) * 100"></div>
              </div>

              <div class="student-actions">
                <button class="btn btn-sm btn-primary" (click)="viewDetailedProgress(student)">
                  <span class="material-icons">analytics</span>
                  View Details
                </button>
              </div>
            </div>
          </div>

          <!-- Table View -->
          <div *ngIf="viewMode === 'table'" class="students-table">
            <div class="table-header">
              <div>Student</div>
              <div>Completed</div>
              <div>Average</div>
              <div>Highest</div>
              <div>Time Spent</div>
              <div>Last Exam</div>
              <div>Actions</div>
            </div>
            <div *ngFor="let student of filteredStudents" class="table-row">
              <div class="student-cell">
                <div class="student-avatar-sm">
                  <span class="material-icons">person</span>
                </div>
                <div>
                  <div class="student-name">{{ student.studentName }}</div>
                  <div class="student-email">{{ student.email }}</div>
                </div>
              </div>
              <div class="completion-cell">
                <span>{{ student.completedExams }}/{{ student.totalExams }}</span>
                <div class="mini-progress">
                  <div class="mini-progress-fill" [style.width.%]="(student.completedExams / student.totalExams) * 100"></div>
                </div>
              </div>
              <div class="score-cell">
                <span class="performance-badge" [class]="getPerformanceClass(student.averageScore)">
                  {{ student.averageScore }}%
                </span>
              </div>
              <div>{{ student.highestScore }}%</div>
              <div>{{ student.totalTimeSpent }} min</div>
              <div>{{ formatDate(student.lastExamDate) }}</div>
              <div class="actions-cell">
                <button class="btn btn-sm btn-primary" (click)="viewDetailedProgress(student)">
                  <span class="material-icons">visibility</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Detailed Progress Modal -->
        <div *ngIf="selectedStudent" class="modal-overlay" (click)="closeDetailedView()">
          <div class="modal-content" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <h2>{{ selectedStudent.studentName }} - Detailed Progress</h2>
              <button class="close-btn" (click)="closeDetailedView()">
                <span class="material-icons">close</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="detailed-stats">
                <div class="stat-card">
                  <div class="stat-icon">
                    <span class="material-icons">assignment_turned_in</span>
                  </div>
                  <div class="stat-content">
                    <div class="stat-value">{{ selectedStudent.completedExams }}</div>
                    <div class="stat-label">Completed Exams</div>
                  </div>
                </div>
                <div class="stat-card">
                  <div class="stat-icon">
                    <span class="material-icons">trending_up</span>
                  </div>
                  <div class="stat-content">
                    <div class="stat-value">{{ selectedStudent.averageScore }}%</div>
                    <div class="stat-label">Average Score</div>
                  </div>
                </div>
                <div class="stat-card">
                  <div class="stat-icon">
                    <span class="material-icons">schedule</span>
                  </div>
                  <div class="stat-content">
                    <div class="stat-value">{{ selectedStudent.totalTimeSpent }}</div>
                    <div class="stat-label">Total Time (min)</div>
                  </div>
                </div>
              </div>

              <div class="exam-results">
                <h3>Exam Results</h3>
                <div class="results-list">
                  <div *ngFor="let result of selectedStudent.examResults" class="result-item">
                    <div class="result-header">
                      <h4>{{ result.examTitle }}</h4>
                      <span class="result-score">{{ result.score }}/{{ result.totalMarks }}</span>
                    </div>
                    <div class="result-details">
                      <span class="percentage">{{ result.percentage }}%</span>
                      <span class="time">{{ result.timeSpent }} min</span>
                      <span class="date">{{ formatDate(result.completedAt) }}</span>
                      <span *ngIf="result.violations > 0" class="violations">
                        {{ result.violations }} violations
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .progress-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: var(--spacing-xl);
    }

    .progress-header {
      margin-bottom: var(--spacing-2xl);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .header-text h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .header-text p {
      color: var(--text-secondary);
      font-size: 1.125rem;
    }

    .header-stats {
      display: flex;
      gap: var(--spacing-xl);
    }

    .stat-item {
      text-align: center;
    }

    .stat-number {
      font-size: 2rem;
      font-weight: 700;
      color: var(--primary-color);
    }

    .stat-label {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .progress-content {
      display: grid;
      gap: var(--spacing-2xl);
    }

    .filters-section,
    .students-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-xl);
      padding-bottom: var(--spacing-lg);
      border-bottom: 2px solid var(--border-color);
    }

    .section-header h2 {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .filters-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
    }

    .filter-item label {
      display: block;
      margin-bottom: var(--spacing-xs);
      font-weight: 500;
      color: var(--text-primary);
    }

    .view-toggle {
      display: flex;
      gap: var(--spacing-xs);
    }

    .students-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: var(--spacing-lg);
    }

    .student-card {
      padding: var(--spacing-xl);
      transition: all 0.3s ease;
    }

    .student-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-xl);
    }

    .student-header {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      margin-bottom: var(--spacing-lg);
    }

    .student-avatar {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.5rem;
    }

    .student-info h3 {
      margin: 0;
      font-size: 1.125rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .student-info p {
      margin: 0;
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .performance-badge {
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-full);
      font-weight: 600;
      font-size: 0.875rem;
      margin-left: auto;
    }

    .performance-badge.excellent {
      background: rgb(34 197 94 / 0.1);
      color: var(--success-color);
    }

    .performance-badge.good {
      background: rgb(59 130 246 / 0.1);
      color: var(--primary-color);
    }

    .performance-badge.average {
      background: rgb(249 115 22 / 0.1);
      color: var(--warning-color);
    }

    .performance-badge.poor {
      background: rgb(239 68 68 / 0.1);
      color: var(--error-color);
    }

    .student-stats {
      margin-bottom: var(--spacing-lg);
    }

    .stat-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: var(--spacing-sm);
    }

    .stat-label {
      color: var(--text-secondary);
    }

    .stat-value {
      font-weight: 500;
      color: var(--text-primary);
    }

    .progress-bar {
      height: 8px;
      background: var(--bg-tertiary);
      border-radius: var(--radius-full);
      margin-bottom: var(--spacing-lg);
      overflow: hidden;
    }

    .progress-fill {
      height: 100%;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: var(--radius-full);
      transition: width 0.3s ease;
    }

    .student-actions {
      display: flex;
      justify-content: center;
    }

    .students-table {
      background: var(--bg-primary);
      border-radius: var(--radius-lg);
      overflow: hidden;
    }

    .table-header {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr 1fr 1.5fr 1fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      font-weight: 600;
      color: var(--text-primary);
    }

    .table-row {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr 1fr 1.5fr 1fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      border-bottom: 1px solid var(--border-light);
      align-items: center;
    }

    .table-row:hover {
      background: var(--bg-tertiary);
    }

    .student-cell {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }

    .student-avatar-sm {
      width: 35px;
      height: 35px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1rem;
    }

    .student-name {
      font-weight: 500;
      color: var(--text-primary);
    }

    .student-email {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .completion-cell {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-xs);
    }

    .mini-progress {
      height: 4px;
      background: var(--bg-tertiary);
      border-radius: var(--radius-full);
      overflow: hidden;
    }

    .mini-progress-fill {
      height: 100%;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: var(--radius-full);
    }

    .actions-cell {
      display: flex;
      justify-content: center;
    }

    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: var(--bg-card);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
      max-width: 800px;
      width: 90%;
      max-height: 90vh;
      overflow-y: auto;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: var(--spacing-xl);
      border-bottom: 1px solid var(--border-color);
    }

    .modal-header h2 {
      margin: 0;
      color: var(--text-primary);
    }

    .close-btn {
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      padding: var(--spacing-xs);
      border-radius: 50%;
      transition: all 0.3s ease;
    }

    .close-btn:hover {
      background: var(--bg-tertiary);
      color: var(--text-primary);
    }

    .modal-body {
      padding: var(--spacing-xl);
    }

    .detailed-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
      margin-bottom: var(--spacing-2xl);
    }

    .stat-card {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      border-radius: var(--radius-lg);
    }

    .stat-icon {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }

    .stat-content .stat-value {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .stat-content .stat-label {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .exam-results h3 {
      margin-bottom: var(--spacing-lg);
      color: var(--text-primary);
    }

    .results-list {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-md);
    }

    .result-item {
      background: var(--bg-tertiary);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
    }

    .result-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-sm);
    }

    .result-header h4 {
      margin: 0;
      color: var(--text-primary);
    }

    .result-score {
      font-weight: 600;
      color: var(--primary-color);
    }

    .result-details {
      display: flex;
      gap: var(--spacing-md);
      font-size: 0.875rem;
      color: var(--text-secondary);
    }

    .percentage {
      font-weight: 600;
      color: var(--success-color);
    }

    .violations {
      color: var(--error-color);
      font-weight: 500;
    }

    @media (max-width: 768px) {
      .progress-container {
        padding: var(--spacing-lg);
      }

      .header-content {
        flex-direction: column;
        gap: var(--spacing-lg);
      }

      .students-grid {
        grid-template-columns: 1fr;
      }

      .table-header,
      .table-row {
        grid-template-columns: 1fr;
        gap: var(--spacing-sm);
      }

      .detailed-stats {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class StudentProgressComponent implements OnInit {
  students: StudentProgress[] = [];
  filteredStudents: StudentProgress[] = [];
  selectedStudent: StudentProgress | null = null;
  viewMode: 'grid' | 'table' = 'grid';
  progressSummary = {
    totalStudents: 0,
    averageCompletion: 0,
    averageScore: 0,
    totalViolations: 0
  };

  constructor(private studentProgressService: StudentProgressService) {}

  ngOnInit(): void {
    this.loadStudentProgress();
    this.loadProgressSummary();
  }

  loadStudentProgress(): void {
    this.studentProgressService.getAllStudentsProgress().subscribe(students => {
      this.students = students;
      this.filteredStudents = students;
    });
  }

  loadProgressSummary(): void {
    this.studentProgressService.getProgressSummary().subscribe(summary => {
      this.progressSummary = summary;
    });
  }

  sortStudents(event: any): void {
    const sortBy = event.target.value;
    this.filteredStudents = [...this.filteredStudents].sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.studentName.localeCompare(b.studentName);
        case 'averageScore':
          return b.averageScore - a.averageScore;
        case 'completedExams':
          return b.completedExams - a.completedExams;
        case 'lastExamDate':
          const dateA = a.lastExamDate ? new Date(a.lastExamDate).getTime() : 0;
          const dateB = b.lastExamDate ? new Date(b.lastExamDate).getTime() : 0;
          return dateB - dateA;
        default:
          return 0;
      }
    });
  }

  filterByPerformance(event: any): void {
    const performance = event.target.value;
    if (performance === 'all') {
      this.filteredStudents = this.students;
    } else {
      this.filteredStudents = this.students.filter(student => {
        switch (performance) {
          case 'excellent':
            return student.averageScore >= 90;
          case 'good':
            return student.averageScore >= 80 && student.averageScore < 90;
          case 'average':
            return student.averageScore >= 70 && student.averageScore < 80;
          case 'poor':
            return student.averageScore < 70;
          default:
            return true;
        }
      });
    }
  }

  getPerformanceClass(score: number): string {
    if (score >= 90) return 'excellent';
    if (score >= 80) return 'good';
    if (score >= 70) return 'average';
    return 'poor';
  }

  viewDetailedProgress(student: StudentProgress): void {
    this.selectedStudent = student;
  }

  closeDetailedView(): void {
    this.selectedStudent = null;
  }

  formatDate(date: Date | string | null): string {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  }
}