import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';
import { NavbarComponent } from '../shared/navbar.component';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="profile-container fade-in">
      <div class="profile-header">
        <div class="header-content">
          <div class="profile-avatar">
            <span class="material-icons">person</span>
          </div>
          <div class="profile-info">
            <h1>{{ currentUser?.firstName }} {{ currentUser?.lastName }}</h1>
            <p class="role-badge">{{ currentUser?.role }}</p>
            <p class="member-since">Member since {{ formatDate(currentUser?.createdAt) }}</p>
          </div>
        </div>
      </div>

      <div class="profile-content">
        <div class="profile-section card">
          <div class="section-header">
            <h2>
              <span class="material-icons">edit</span>
              Edit Profile
            </h2>
          </div>

          <form [formGroup]="profileForm" (ngSubmit)="updateProfile()">
            <div class="form-grid">
              <div class="form-group">
                <label class="form-label">First Name</label>
                <input type="text" formControlName="firstName" class="form-input">
              </div>
              <div class="form-group">
                <label class="form-label">Last Name</label>
                <input type="text" formControlName="lastName" class="form-input">
              </div>
              <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" formControlName="email" class="form-input">
              </div>
              <div class="form-group">
                <label class="form-label">Phone</label>
                <input type="tel" formControlName="phone" class="form-input">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-primary" [disabled]="profileForm.invalid || isUpdating">
                <span *ngIf="isUpdating" class="spinner"></span>
                {{ isUpdating ? 'Updating...' : 'Update Profile' }}
              </button>
            </div>
          </form>
        </div>

        <div class="password-section card">
          <div class="section-header">
            <h2>
              <span class="material-icons">lock</span>
              Change Password
            </h2>
          </div>

          <form [formGroup]="passwordForm" (ngSubmit)="changePassword()">
            <div class="form-grid">
              <div class="form-group">
                <label class="form-label">Current Password</label>
                <input type="password" formControlName="currentPassword" class="form-input">
              </div>
              <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" formControlName="newPassword" class="form-input">
              </div>
              <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <input type="password" formControlName="confirmPassword" class="form-input">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-primary" [disabled]="passwordForm.invalid || isChangingPassword">
                <span *ngIf="isChangingPassword" class="spinner"></span>
                {{ isChangingPassword ? 'Changing...' : 'Change Password' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .profile-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: var(--spacing-xl);
    }

    .profile-header {
      margin-bottom: var(--spacing-2xl);
    }

    .header-content {
      display: flex;
      align-items: center;
      gap: var(--spacing-xl);
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .profile-avatar {
      width: 120px;
      height: 120px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 4rem;
    }

    .profile-info h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .role-badge {
      display: inline-block;
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      padding: var(--spacing-xs) var(--spacing-md);
      border-radius: var(--radius-full);
      font-size: 0.875rem;
      font-weight: 500;
      text-transform: uppercase;
      margin-bottom: var(--spacing-sm);
    }

    .member-since {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .profile-content {
      display: grid;
      gap: var(--spacing-2xl);
      max-width: 800px;
    }

    .profile-section,
    .password-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .section-header {
      margin-bottom: var(--spacing-xl);
      padding-bottom: var(--spacing-lg);
      border-bottom: 2px solid var(--border-color);
    }

    .section-header h2 {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
      margin-bottom: var(--spacing-xl);
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
    }

    @media (max-width: 768px) {
      .profile-container {
        padding: var(--spacing-lg);
      }

      .header-content {
        flex-direction: column;
        text-align: center;
      }

      .form-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class ProfileComponent implements OnInit {
  currentUser: User | null = null;
  profileForm: FormGroup;
  passwordForm: FormGroup;
  isUpdating = false;
  isChangingPassword = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService
  ) {
    this.profileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['']
    });

    this.passwordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.profileForm.patchValue({
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phone: user.phone || ''
        });
      }
    });
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword');
    const confirmPassword = form.get('confirmPassword');
    
    if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
      confirmPassword.setErrors({ mismatch: true });
    } else {
      confirmPassword?.setErrors(null);
    }
    
    return null;
  }

  updateProfile(): void {
    if (this.profileForm.valid) {
      this.isUpdating = true;
      setTimeout(() => {
        this.isUpdating = false;
        alert('Profile updated successfully!');
      }, 1000);
    }
  }

  changePassword(): void {
    if (this.passwordForm.valid) {
      this.isChangingPassword = true;
      setTimeout(() => {
        this.isChangingPassword = false;
        this.passwordForm.reset();
        alert('Password changed successfully!');
      }, 1000);
    }
  }

  formatDate(date: Date | string | null | undefined): string {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  }
}