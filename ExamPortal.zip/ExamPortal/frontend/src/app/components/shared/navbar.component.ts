import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User, UserRole } from '../../models/user.model';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-brand" routerLink="/dashboard">
          <div class="brand-icon">
            <span class="material-icons">school</span>
          </div>
          <div class="brand-text">
            <h2>ExamPortal</h2>
            <span>Smart Exam System</span>
          </div>
        </div>

        <div class="nav-menu" *ngIf="currentUser">
          <div class="nav-links">
            <a routerLink="/dashboard" routerLinkActive="active" class="nav-link">
              <span class="material-icons">dashboard</span>
              <span>Dashboard</span>
            </a>
            
            <a *ngIf="isAdmin()" routerLink="/admin" routerLinkActive="active" class="nav-link">
              <span class="material-icons">admin_panel_settings</span>
              <span>Admin</span>
            </a>
            
            <a *ngIf="isInstructor()" routerLink="/instructor" routerLinkActive="active" class="nav-link">
              <span class="material-icons">school</span>
              <span>Instructor</span>
            </a>
            
            <a *ngIf="isAdmin() || isInstructor()" routerLink="/student-progress" routerLinkActive="active" class="nav-link">
              <span class="material-icons">analytics</span>
              <span>Student Progress</span>
            </a>
            
            <a *ngIf="isStudent()" routerLink="/student" routerLinkActive="active" class="nav-link">
              <span class="material-icons">quiz</span>
              <span>My Exams</span>
            </a>
          </div>

          <div class="nav-actions">
            <div class="theme-toggle" (click)="toggleTheme()">
              <span class="material-icons">{{ currentTheme === 'light' ? 'dark_mode' : 'light_mode' }}</span>
            </div>
            
            <div class="user-menu">
              <div class="user-avatar" (click)="toggleUserDropdown()">
                <span class="material-icons">person</span>
              </div>
              
              <div class="user-dropdown" [class.show]="showUserDropdown">
                <div class="user-info">
                  <div class="user-name">{{ currentUser.firstName }} {{ currentUser.lastName }}</div>
                  <div class="user-role">{{ currentUser.role }}</div>
                </div>
                <div class="dropdown-divider"></div>
                <button class="dropdown-item" routerLink="/profile" (click)="showUserDropdown = false">
                  <span class="material-icons">person</span>
                  <span>Profile</span>
                </button>
                <button class="dropdown-item" (click)="logout()">
                  <span class="material-icons">logout</span>
                  <span>Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      background: var(--bg-card);
      box-shadow: var(--shadow-lg);
      border-bottom: 1px solid var(--border-color);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(10px);
    }

    .nav-container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 var(--spacing-lg);
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 70px;
    }

    .nav-brand {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      cursor: pointer;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    .nav-brand:hover {
      transform: scale(1.02);
    }

    .brand-icon {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.5rem;
      animation: rotate 10s linear infinite;
    }

    @keyframes rotate {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .brand-text h2 {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 700;
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .brand-text span {
      font-size: 0.75rem;
      color: var(--text-muted);
      font-weight: 500;
    }

    .nav-menu {
      display: flex;
      align-items: center;
      gap: var(--spacing-xl);
    }

    .nav-links {
      display: flex;
      gap: var(--spacing-lg);
    }

    .nav-link {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      padding: var(--spacing-sm) var(--spacing-md);
      border-radius: var(--radius-md);
      text-decoration: none;
      color: var(--text-secondary);
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }

    .nav-link::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
      transition: left 0.5s;
    }

    .nav-link:hover::before {
      left: 100%;
    }

    .nav-link:hover,
    .nav-link.active {
      color: var(--primary-color);
      background: rgba(99, 102, 241, 0.1);
      transform: translateY(-2px);
    }

    .nav-actions {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
    }

    .theme-toggle {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s ease;
      color: var(--text-secondary);
    }

    .theme-toggle:hover {
      background: var(--bg-tertiary);
      color: var(--primary-color);
      transform: scale(1.1);
    }

    .user-menu {
      position: relative;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .user-avatar:hover {
      transform: scale(1.1);
      box-shadow: var(--shadow-md);
    }

    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: var(--spacing-sm);
      background: var(--bg-card);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-xl);
      border: 1px solid var(--border-color);
      min-width: 200px;
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
    }

    .user-dropdown.show {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .user-info {
      padding: var(--spacing-lg);
    }

    .user-name {
      font-weight: 600;
      color: var(--text-primary);
    }

    .user-role {
      font-size: 0.875rem;
      color: var(--text-secondary);
      text-transform: capitalize;
    }

    .dropdown-divider {
      height: 1px;
      background: var(--border-color);
      margin: 0 var(--spacing-lg);
    }

    .dropdown-item {
      width: 100%;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      padding: var(--spacing-md) var(--spacing-lg);
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.875rem;
    }

    .dropdown-item:hover {
      background: var(--bg-tertiary);
      color: var(--error-color);
    }

    @media (max-width: 768px) {
      .nav-container {
        padding: 0 var(--spacing-md);
      }

      .nav-links {
        display: none;
      }

      .brand-text span {
        display: none;
      }
    }
  `]
})
export class NavbarComponent implements OnInit {
  currentUser: User | null = null;
  currentTheme = 'light';
  showUserDropdown = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    
    this.currentTheme = localStorage.getItem('theme') || 'light';
  }

  toggleTheme(): void {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('theme', this.currentTheme);
    document.documentElement.setAttribute('data-theme', this.currentTheme);
  }

  toggleUserDropdown(): void {
    this.showUserDropdown = !this.showUserDropdown;
  }

  logout(): void {
    this.authService.logout().subscribe(() => {
      this.router.navigate(['/auth/login']);
    });
  }

  isAdmin(): boolean {
    return this.authService.hasRole(UserRole.ADMIN);
  }

  isInstructor(): boolean {
    return this.authService.hasAnyRole([UserRole.ADMIN, UserRole.INSTRUCTOR]);
  }

  isStudent(): boolean {
    return this.authService.hasRole(UserRole.STUDENT);
  }
}