import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User, UserRole } from '../../models/user.model';
import { NavbarComponent } from '../shared/navbar.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="dashboard-container fade-in">

      <div class="dashboard-content">
        <div class="welcome-section slide-up">
          <h1>Welcome back, {{ currentUser?.firstName }}!</h1>
          <p class="welcome-subtitle">{{ getRoleMessage() }}</p>
        </div>

        <div class="dashboard-grid">
          <div *ngIf="isAdmin()" class="dashboard-card card" (click)="navigateTo('/admin')">
            <div class="card-icon admin">
              <span class="material-icons">admin_panel_settings</span>
            </div>
            <h3>Admin Panel</h3>
            <p>Manage users, system settings, and view analytics</p>
          </div>

          <div *ngIf="isInstructor()" class="dashboard-card card" (click)="navigateTo('/instructor')">
            <div class="card-icon instructor">
              <span class="material-icons">school</span>
            </div>
            <h3>Instructor Dashboard</h3>
            <p>Create exams, manage questions, and view results</p>
          </div>

          <div *ngIf="isStudent()" class="dashboard-card card" (click)="navigateTo('/student')">
            <div class="card-icon student">
              <span class="material-icons">quiz</span>
            </div>
            <h3>Student Portal</h3>
            <p>Take exams, view results, and track progress</p>
          </div>

          <div class="dashboard-card card" (click)="navigateTo('/profile')">
            <div class="card-icon profile">
              <span class="material-icons">person</span>
            </div>
            <h3>Profile</h3>
            <p>Update your personal information and settings</p>
          </div>
        </div>

        <div class="quick-stats">
          <h2>Quick Overview</h2>
          <div class="stats-grid">
            <div class="stat-card card">
              <div class="stat-value">{{ stats.totalExams }}</div>
              <div class="stat-label">Total Exams</div>
            </div>
            <div class="stat-card card">
              <div class="stat-value">{{ stats.completedExams }}</div>
              <div class="stat-label">Completed</div>
            </div>
            <div class="stat-card card">
              <div class="stat-value">{{ stats.averageScore }}%</div>
              <div class="stat-label">Average Score</div>
            </div>
            <div class="stat-card card">
              <div class="stat-value">{{ stats.upcomingExams }}</div>
              <div class="stat-label">Upcoming</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }



    .dashboard-content {
      padding: var(--spacing-2xl);
      max-width: 1200px;
      margin: 0 auto;
    }

    .welcome-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
      margin-bottom: var(--spacing-2xl);
    }

    .welcome-section {
      text-align: center;
      margin-bottom: var(--spacing-2xl);
    }

    .welcome-section h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .welcome-subtitle {
      font-size: 1.125rem;
      color: var(--text-secondary);
    }

    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: var(--spacing-xl);
      margin-bottom: var(--spacing-2xl);
    }

    .dashboard-card {
      padding: var(--spacing-xl);
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      background: var(--bg-card);
      position: relative;
      overflow: hidden;
    }

    .dashboard-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
      transition: left 0.5s;
    }

    .dashboard-card:hover::before {
      left: 100%;
    }

    .dashboard-card:hover {
      transform: translateY(-8px) scale(1.02);
      box-shadow: var(--shadow-xl);
    }

    .card-icon {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto var(--spacing-lg);
      font-size: 2rem;
    }

    .card-icon.admin {
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
    }

    .card-icon.instructor {
      background: linear-gradient(135deg, #3b82f6, #2563eb);
      color: white;
    }

    .card-icon.student {
      background: linear-gradient(135deg, #10b981, #059669);
      color: white;
    }

    .card-icon.profile {
      background: linear-gradient(135deg, #8b5cf6, #7c3aed);
      color: white;
    }

    .dashboard-card h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .dashboard-card p {
      color: var(--text-secondary);
      line-height: 1.6;
    }

    .quick-stats h2 {
      text-align: center;
      margin-bottom: var(--spacing-xl);
      color: var(--text-primary);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
    }

    .stat-card {
      padding: var(--spacing-xl);
      text-align: center;
    }

    .stat-value {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--primary-color);
      margin-bottom: var(--spacing-sm);
    }

    .stat-label {
      color: var(--text-secondary);
      font-weight: 500;
      text-transform: uppercase;
      font-size: 0.875rem;
      letter-spacing: 0.05em;
    }

    @media (max-width: 768px) {


      .dashboard-content {
        padding: var(--spacing-lg);
      }

      .welcome-section h1 {
        font-size: 2rem;
      }

      .dashboard-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  currentTheme = 'light';
  stats = {
    totalExams: 0,
    completedExams: 0,
    averageScore: 0,
    upcomingExams: 0
  };

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.currentTheme = localStorage.getItem('theme') || 'light';
    this.loadStats();
  }

  toggleTheme(): void {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('theme', this.currentTheme);
    document.documentElement.setAttribute('data-theme', this.currentTheme);
  }

  logout(): void {
    this.authService.logout().subscribe(() => {
      this.router.navigate(['/auth/login']);
    });
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
  }

  isAdmin(): boolean {
    return this.authService.hasRole(UserRole.ADMIN);
  }

  isInstructor(): boolean {
    return this.authService.hasAnyRole([UserRole.ADMIN, UserRole.INSTRUCTOR]);
  }

  isStudent(): boolean {
    return this.authService.hasRole(UserRole.STUDENT);
  }

  getRoleMessage(): string {
    const role = this.currentUser?.role;
    switch (role) {
      case UserRole.ADMIN:
        return 'Manage the entire exam portal system';
      case UserRole.INSTRUCTOR:
        return 'Create and manage exams for your students';
      case UserRole.STUDENT:
        return 'Take exams and track your academic progress';
      default:
        return 'Welcome to ExamPortal';
    }
  }

  private loadStats(): void {
    // Mock data - replace with actual API calls
    this.stats = {
      totalExams: 12,
      completedExams: 8,
      averageScore: 85,
      upcomingExams: 4
    };
  }
}