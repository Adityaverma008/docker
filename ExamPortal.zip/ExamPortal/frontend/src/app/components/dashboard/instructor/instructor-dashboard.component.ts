import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ExamService } from '../../../services/exam.service';
import { StudentProgressService } from '../../../services/student-progress.service';
import { Exam, Question, QuestionType, DifficultyLevel } from '../../../models/exam.model';
import { NavbarComponent } from '../../shared/navbar.component';

@Component({
  selector: 'app-instructor-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="instructor-dashboard fade-in">
      <!-- Header -->
      <div class="dashboard-header">
        <div class="header-content">
          <div class="header-text">
            <h1>Instructor Hub</h1>
            <p>Create and manage exams for your students</p>
          </div>
          <div class="header-image">
            <div class="instructor-avatar">
              <span class="material-icons">school</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="stats-section">
        <div class="stats-grid">
          <div class="stat-card card scale-in" style="animation-delay: 0.1s">
            <div class="stat-icon exams">
              <span class="material-icons">quiz</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalExams }}</div>
              <div class="stat-label">My Exams</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.2s">
            <div class="stat-icon questions">
              <span class="material-icons">help_outline</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalQuestions }}</div>
              <div class="stat-label">Questions</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.3s">
            <div class="stat-icon students">
              <span class="material-icons">people</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalStudents }}</div>
              <div class="stat-label">Students</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.4s">
            <div class="stat-icon average">
              <span class="material-icons">trending_up</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.averageScore }}%</div>
              <div class="stat-label">Avg Score</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content -->
      <div class="main-content">
        <!-- Exam Management -->
        <div class="exam-section card slide-up">
          <div class="section-header">
            <h2>
              <span class="material-icons">assignment</span>
              Exam Management
            </h2>
            <button class="btn btn-primary" (click)="toggleCreateExam()">
              <span class="material-icons">add</span>
              Create Exam
            </button>
          </div>

          <!-- Create Exam Form -->
          <div class="create-exam-form" *ngIf="showCreateExamForm">
            <form [formGroup]="createExamForm" (ngSubmit)="createExam()">
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">Exam Title</label>
                  <input type="text" formControlName="title" class="form-input" placeholder="Enter exam title">
                </div>
                <div class="form-group">
                  <label class="form-label">Duration (minutes)</label>
                  <input type="number" formControlName="duration" class="form-input" placeholder="60">
                </div>
                <div class="form-group full-width">
                  <label class="form-label">Description</label>
                  <textarea formControlName="description" class="form-input" rows="3" placeholder="Enter exam description"></textarea>
                </div>
              </div>
              <div class="form-actions">
                <button type="button" class="btn btn-secondary" (click)="toggleCreateExam()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="createExamForm.invalid">
                  Create Exam
                </button>
              </div>
            </form>
          </div>

          <!-- Exams List -->
          <div class="exams-grid">
            <div *ngFor="let exam of exams" class="exam-card card">
              <div class="exam-header">
                <h3>{{ exam.title }}</h3>
                <span class="exam-status" [class]="exam.active ? 'active' : 'inactive'">
                  {{ exam.active ? 'Active' : 'Inactive' }}
                </span>
              </div>
              <p class="exam-description">{{ exam.description }}</p>
              <div class="exam-details">
                <div class="detail-item">
                  <span class="material-icons">schedule</span>
                  <span>{{ exam.duration }} minutes</span>
                </div>
                <div class="detail-item">
                  <span class="material-icons">quiz</span>
                  <span>{{ exam.questions.length || 0 }} questions</span>
                </div>
                <div class="detail-item">
                  <span class="material-icons">grade</span>
                  <span>{{ exam.totalMarks }} points</span>
                </div>
              </div>
              <div class="exam-actions">
                <button class="btn btn-sm btn-secondary">
                  <span class="material-icons">edit</span>
                  Edit
                </button>
                <button class="btn btn-sm btn-primary">
                  <span class="material-icons">visibility</span>
                  View
                </button>
                <button class="btn btn-sm btn-success">
                  <span class="material-icons">analytics</span>
                  Results
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Student Progress Overview -->
        <div class="progress-overview-section card slide-up" style="animation-delay: 0.2s">
          <div class="section-header">
            <h2>
              <span class="material-icons">trending_up</span>
              My Students Progress
            </h2>
            <button class="btn btn-primary" routerLink="/student-progress">
              <span class="material-icons">analytics</span>
              View Detailed Progress
            </button>
          </div>
          
          <div class="progress-summary">
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">people</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.totalStudents }}</div>
                <div class="summary-label">My Students</div>
              </div>
            </div>
            
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">assignment_turned_in</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.averageCompletion }}%</div>
                <div class="summary-label">Avg Completion</div>
              </div>
            </div>
            
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">grade</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.averageScore }}%</div>
                <div class="summary-label">Avg Score</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Question Bank -->
        <div class="question-section card slide-up" style="animation-delay: 0.3s">
          <div class="section-header">
            <h2>
              <span class="material-icons">help_outline</span>
              Question Bank
            </h2>
            <button class="btn btn-primary" (click)="toggleCreateQuestion()">
              <span class="material-icons">add</span>
              Add Question
            </button>
          </div>

          <!-- Create Question Form -->
          <div class="create-question-form" *ngIf="showCreateQuestionForm">
            <form [formGroup]="createQuestionForm" (ngSubmit)="createQuestion()">
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">Question Type</label>
                  <select formControlName="type" class="form-input">
                    <option value="MCQ">Multiple Choice</option>
                    <option value="SHORT_ANSWER">Short Answer</option>
                    <option value="TRUE_FALSE">True/False</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Difficulty</label>
                  <select formControlName="difficulty" class="form-input">
                    <option value="EASY">Easy</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HARD">Hard</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Category</label>
                  <input type="text" formControlName="category" class="form-input" placeholder="e.g., Mathematics">
                </div>
                <div class="form-group">
                  <label class="form-label">Points</label>
                  <input type="number" formControlName="points" class="form-input" placeholder="1">
                </div>
                <div class="form-group full-width">
                  <label class="form-label">Question Content</label>
                  <textarea formControlName="content" class="form-input" rows="3" placeholder="Enter your question"></textarea>
                </div>
                <div class="form-group full-width">
                  <label class="form-label">Correct Answer</label>
                  <input type="text" formControlName="correctAnswer" class="form-input" placeholder="Enter correct answer">
                </div>
              </div>
              <div class="form-actions">
                <button type="button" class="btn btn-secondary" (click)="toggleCreateQuestion()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="createQuestionForm.invalid">
                  Add Question
                </button>
              </div>
            </form>
          </div>

          <!-- Questions List -->
          <div class="questions-list">
            <div *ngFor="let question of questions" class="question-item">
              <div class="question-header">
                <span class="question-type badge" [class]="'badge-' + question.type.toLowerCase()">{{ question.type }}</span>
                <span class="question-difficulty badge" [class]="'badge-' + question.difficulty.toLowerCase()">{{ question.difficulty }}</span>
                <span class="question-points">{{ question.points }} pts</span>
              </div>
              <div class="question-content">{{ question.content }}</div>
              <div class="question-meta">
                <span class="category">{{ question.category }}</span>
                <span class="created">Created {{ formatDate(question.createdAt) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .instructor-dashboard {
      min-height: 100vh;
      background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      padding: var(--spacing-xl);
    }

    .dashboard-header {
      margin-bottom: var(--spacing-2xl);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .header-text h1 {
      font-size: 3rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
      background: linear-gradient(135deg, #f093fb, #f5576c);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-text p {
      font-size: 1.25rem;
      color: var(--text-secondary);
    }

    .instructor-avatar {
      width: 100px;
      height: 100px;
      background: linear-gradient(135deg, #f093fb, #f5576c);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 3rem;
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }

    .stats-section {
      margin-bottom: var(--spacing-2xl);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
    }

    .stat-card {
      padding: var(--spacing-xl);
      display: flex;
      align-items: center;
      gap: var(--spacing-lg);
      background: var(--bg-card);
      transition: all 0.3s ease;
    }

    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: var(--shadow-xl);
    }

    .stat-icon {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.5rem;
    }

    .stat-icon.exams { background: linear-gradient(135deg, #f093fb, #f5576c); }
    .stat-icon.questions { background: linear-gradient(135deg, #4facfe, #00f2fe); }
    .stat-icon.students { background: linear-gradient(135deg, #43e97b, #38f9d7); }
    .stat-icon.average { background: linear-gradient(135deg, #fa709a, #fee140); }

    .stat-value {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .stat-label {
      color: var(--text-secondary);
      font-weight: 500;
    }

    .main-content {
      display: grid;
      gap: var(--spacing-2xl);
    }

    .exam-section,
    .question-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-xl);
      padding-bottom: var(--spacing-lg);
      border-bottom: 2px solid var(--border-color);
    }

    .section-header h2 {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .create-exam-form,
    .create-question-form {
      background: var(--bg-tertiary);
      padding: var(--spacing-xl);
      border-radius: var(--radius-lg);
      margin-bottom: var(--spacing-xl);
    }

    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
      margin-bottom: var(--spacing-xl);
    }

    .form-group.full-width {
      grid-column: 1 / -1;
    }

    .form-actions {
      display: flex;
      gap: var(--spacing-md);
      justify-content: flex-end;
    }

    .exams-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: var(--spacing-lg);
    }

    .exam-card {
      padding: var(--spacing-xl);
      transition: all 0.3s ease;
    }

    .exam-card:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-xl);
    }

    .exam-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: var(--spacing-md);
    }

    .exam-header h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .exam-status {
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: uppercase;
    }

    .exam-status.active {
      background: rgb(34 197 94 / 0.1);
      color: var(--success-color);
    }

    .exam-status.inactive {
      background: rgb(239 68 68 / 0.1);
      color: var(--error-color);
    }

    .exam-description {
      color: var(--text-secondary);
      margin-bottom: var(--spacing-lg);
      line-height: 1.6;
    }

    .exam-details {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-sm);
      margin-bottom: var(--spacing-lg);
    }

    .detail-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .detail-item .material-icons {
      font-size: 1rem;
      color: var(--primary-color);
    }

    .exam-actions {
      display: flex;
      gap: var(--spacing-sm);
      justify-content: flex-end;
    }

    .questions-list {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-lg);
    }

    .question-item {
      background: var(--bg-tertiary);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
      transition: all 0.3s ease;
    }

    .question-item:hover {
      background: var(--bg-primary);
      box-shadow: var(--shadow-md);
    }

    .question-header {
      display: flex;
      gap: var(--spacing-sm);
      margin-bottom: var(--spacing-md);
      align-items: center;
    }

    .question-type.badge-mcq { background: #f093fb; color: white; }
    .question-type.badge-short_answer { background: #4facfe; color: white; }
    .question-type.badge-true_false { background: #43e97b; color: white; }

    .question-difficulty.badge-easy { background: #43e97b; color: white; }
    .question-difficulty.badge-medium { background: #fa709a; color: white; }
    .question-difficulty.badge-hard { background: #f5576c; color: white; }

    .question-points {
      margin-left: auto;
      font-weight: 600;
      color: var(--primary-color);
    }

    .question-content {
      font-weight: 500;
      color: var(--text-primary);
      margin-bottom: var(--spacing-md);
      line-height: 1.6;
    }

    .question-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.875rem;
      color: var(--text-muted);
    }

    .category {
      font-weight: 500;
      color: var(--text-secondary);
    }

    .progress-overview-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .progress-summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
    }

    .summary-card {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      border-radius: var(--radius-lg);
      transition: all 0.3s ease;
    }

    .summary-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }

    .summary-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.25rem;
      background: linear-gradient(135deg, #f093fb, #f5576c);
    }

    .summary-value {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .summary-label {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    @media (max-width: 768px) {
      .instructor-dashboard {
        padding: var(--spacing-lg);
      }

      .header-content {
        flex-direction: column;
        text-align: center;
        gap: var(--spacing-lg);
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }

      .exams-grid {
        grid-template-columns: 1fr;
      }

      .form-grid {
        grid-template-columns: 1fr;
      }

      .exam-actions {
        flex-direction: column;
      }
    }
  `]
})
export class InstructorDashboardComponent implements OnInit {
  showCreateExamForm = false;
  showCreateQuestionForm = false;
  createExamForm: FormGroup;
  createQuestionForm: FormGroup;
  
  exams: Exam[] = [];
  questions: Question[] = [];
  
  stats = {
    totalExams: 8,
    totalQuestions: 45,
    totalStudents: 120,
    averageScore: 78
  };

  progressSummary = {
    totalStudents: 0,
    averageCompletion: 0,
    averageScore: 0,
    totalViolations: 0
  };

  constructor(
    private fb: FormBuilder,
    private examService: ExamService,
    private studentProgressService: StudentProgressService
  ) {
    this.createExamForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      duration: [60, [Validators.required, Validators.min(1)]]
    });

    this.createQuestionForm = this.fb.group({
      content: ['', Validators.required],
      type: [QuestionType.MCQ, Validators.required],
      difficulty: [DifficultyLevel.MEDIUM, Validators.required],
      category: ['', Validators.required],
      points: [1, [Validators.required, Validators.min(1)]],
      correctAnswer: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadSampleData();
    this.loadProgressSummary();
  }

  toggleCreateExam(): void {
    this.showCreateExamForm = !this.showCreateExamForm;
    if (!this.showCreateExamForm) {
      this.createExamForm.reset();
    }
  }

  toggleCreateQuestion(): void {
    this.showCreateQuestionForm = !this.showCreateQuestionForm;
    if (!this.showCreateQuestionForm) {
      this.createQuestionForm.reset();
    }
  }

  createExam(): void {
    if (this.createExamForm.valid) {
      const examData: Exam = {
        ...this.createExamForm.value,
        id: Date.now(),
        active: true,
        totalMarks: 100,
        startTime: new Date(),
        endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        randomizeQuestions: false,
        instructor: null,
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      this.exams.unshift(examData);
      this.stats.totalExams = this.exams.length;
      this.showCreateExamForm = false;
      this.createExamForm.reset();
    }
  }

  createQuestion(): void {
    if (this.createQuestionForm.valid) {
      const questionData: Question = {
        ...this.createQuestionForm.value,
        id: Date.now(),
        options: this.createQuestionForm.value.type === QuestionType.MCQ ? 
          ['Option A', 'Option B', 'Option C', 'Option D'] : 
          this.createQuestionForm.value.type === QuestionType.TRUE_FALSE ? 
          ['True', 'False'] : [],
        tags: '',
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      this.questions.unshift(questionData);
      this.stats.totalQuestions = this.questions.length;
      this.showCreateQuestionForm = false;
      this.createQuestionForm.reset();
    }
  }

  loadSampleData(): void {
    // Sample exams
    this.exams = [
      {
        id: 1,
        title: 'Mathematics Final Exam',
        description: 'Comprehensive mathematics exam covering algebra, geometry, and calculus',
        duration: 120,
        totalMarks: 100,
        active: true,
        randomizeQuestions: false,
        startTime: new Date(),
        endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        instructor: null,
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date('2024-01-15'),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: 'Physics Quiz',
        description: 'Quick assessment on mechanics and thermodynamics',
        duration: 45,
        totalMarks: 50,
        active: true,
        randomizeQuestions: true,
        startTime: new Date(),
        endTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        instructor: null,
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date('2024-02-01'),
        updatedAt: new Date()
      }
    ];

    // Sample questions
    this.questions = [
      {
        id: 1,
        content: 'What is the derivative of x²?',
        type: QuestionType.SHORT_ANSWER,
        difficulty: DifficultyLevel.EASY,
        category: 'Mathematics',
        tags: 'calculus,derivatives',
        points: 2,
        options: [],
        correctAnswer: '2x',
        createdAt: new Date('2024-01-10'),
        updatedAt: new Date()
      },
      {
        id: 2,
        content: 'Which of the following is Newton\'s first law?',
        type: QuestionType.MCQ,
        difficulty: DifficultyLevel.MEDIUM,
        category: 'Physics',
        tags: 'mechanics,laws',
        points: 3,
        options: ['F=ma', 'An object at rest stays at rest', 'Action-reaction', 'Conservation of energy'],
        correctAnswer: 'An object at rest stays at rest',
        createdAt: new Date('2024-01-12'),
        updatedAt: new Date()
      },
      {
        id: 3,
        content: 'The Earth is flat.',
        type: QuestionType.TRUE_FALSE,
        difficulty: DifficultyLevel.EASY,
        category: 'Geography',
        tags: 'earth,basic',
        points: 1,
        options: ['True', 'False'],
        correctAnswer: 'False',
        createdAt: new Date('2024-01-14'),
        updatedAt: new Date()
      }
    ];
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString();
  }

  loadProgressSummary(): void {
    this.studentProgressService.getProgressSummary().subscribe(summary => {
      this.progressSummary = summary;
    });
  }
}