import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ExamService } from '../../../services/exam.service';
import { Exam, ExamSession, Question } from '../../../models/exam.model';
import { NavbarComponent } from '../../shared/navbar.component';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="student-dashboard fade-in">
      <div class="dashboard-header">
        <div class="header-content">
          <div class="header-text">
            <h1>Student Portal</h1>
            <p>Take exams, track progress, and achieve excellence</p>
          </div>
          <div class="header-stats">
            <div class="stat-item">
              <div class="stat-number">{{ performanceStats.totalExams }}</div>
              <div class="stat-label">Exams Taken</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ performanceStats.averageScore }}%</div>
              <div class="stat-label">Average Score</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Available Exams -->
      <section class="exams-section">
        <h2>Available Exams</h2>
        <div class="exams-grid" *ngIf="availableExams.length > 0; else noExams">
          <div *ngFor="let exam of availableExams" class="exam-card card">
            <div class="exam-header">
              <h3>{{ exam.title }}</h3>
              <span class="exam-duration">{{ exam.duration }} min</span>
            </div>
            <p class="exam-description">{{ exam.description }}</p>
            <div class="exam-details">
              <div class="detail-item">
                <span class="material-icons">quiz</span>
                <span>{{ exam.questions.length || 0 }} Questions</span>
              </div>
              <div class="detail-item">
                <span class="material-icons">grade</span>
                <span>{{ exam.totalMarks }} Points</span>
              </div>
              <div class="detail-item">
                <span class="material-icons">schedule</span>
                <span>Due: {{ formatDate(exam.endTime) }}</span>
              </div>
            </div>
            <div class="exam-actions">
              <button class="btn btn-primary" [routerLink]="['/exam', exam.id]">
                Start Exam
              </button>
            </div>
          </div>
        </div>
        
        <ng-template #noExams>
          <div class="empty-state">
            <span class="material-icons">assignment</span>
            <h3>No Available Exams</h3>
            <p>You don't have any exams assigned at the moment.</p>
          </div>
        </ng-template>
      </section>

      <!-- Recent Results -->
      <section class="results-section">
        <h2>Recent Results</h2>
        <div class="results-table" *ngIf="recentSessions.length > 0; else noResults">
          <div class="table-header">
            <div>Exam</div>
            <div>Score</div>
            <div>Percentage</div>
            <div>Status</div>
            <div>Date</div>
          </div>
          <div *ngFor="let session of recentSessions" class="table-row">
            <div class="exam-name">{{ session.exam.title }}</div>
            <div class="score">{{ session.score }}/{{ session.exam.totalMarks }}</div>
            <div class="percentage">{{ session.percentage | number:'1.1-1' }}%</div>
            <div class="status">
              <span class="badge" [class]="getStatusClass(session.status)">
                {{ session.status }}
              </span>
            </div>
            <div class="date">{{ formatDate(session.submittedAt) }}</div>
          </div>
        </div>
        
        <ng-template #noResults>
          <div class="empty-state">
            <span class="material-icons">assessment</span>
            <h3>No Results Yet</h3>
            <p>Your exam results will appear here once you complete exams.</p>
          </div>
        </ng-template>
      </section>

      <!-- Performance Overview -->
      <section class="performance-section">
        <h2>Performance Overview</h2>
        <div class="stats-grid">
          <div class="stat-card card">
            <div class="stat-icon">
              <span class="material-icons">assignment_turned_in</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ performanceStats.totalExams }}</div>
              <div class="stat-label">Exams Completed</div>
            </div>
          </div>
          
          <div class="stat-card card">
            <div class="stat-icon">
              <span class="material-icons">trending_up</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ performanceStats.averageScore }}%</div>
              <div class="stat-label">Average Score</div>
            </div>
          </div>
          
          <div class="stat-card card">
            <div class="stat-icon">
              <span class="material-icons">emoji_events</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ performanceStats.highestScore }}%</div>
              <div class="stat-label">Highest Score</div>
            </div>
          </div>
          
          <div class="stat-card card">
            <div class="stat-icon">
              <span class="material-icons">schedule</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ performanceStats.upcomingExams }}</div>
              <div class="stat-label">Upcoming Exams</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .student-dashboard {
      min-height: 100vh;
      background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      padding: var(--spacing-xl);
    }

    .dashboard-header {
      margin-bottom: var(--spacing-2xl);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .header-text h1 {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: var(--spacing-sm);
      background: linear-gradient(135deg, #4facfe, #00f2fe);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-text p {
      font-size: 1.25rem;
      color: var(--text-secondary);
    }

    .header-stats {
      display: flex;
      gap: var(--spacing-xl);
    }

    .stat-item {
      text-align: center;
    }

    .stat-number {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--primary-color);
    }

    .stat-label {
      color: var(--text-secondary);
      font-weight: 500;
    }

    section {
      margin-bottom: var(--spacing-2xl);
    }

    section h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-lg);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }

    .exams-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: var(--spacing-lg);
    }

    .exam-card {
      padding: var(--spacing-xl);
      transition: all 0.3s ease;
    }

    .exam-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-xl);
    }

    .exam-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: var(--spacing-md);
    }

    .exam-header h3 {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0;
    }

    .exam-duration {
      background: var(--primary-color);
      color: white;
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      font-size: 0.75rem;
      font-weight: 500;
    }

    .exam-description {
      color: var(--text-secondary);
      margin-bottom: var(--spacing-lg);
      line-height: 1.6;
    }

    .exam-details {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-sm);
      margin-bottom: var(--spacing-lg);
    }

    .detail-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .detail-item .material-icons {
      font-size: 1rem;
      color: var(--primary-color);
    }

    .exam-actions {
      display: flex;
      justify-content: flex-end;
    }

    .results-table {
      background: var(--bg-card);
      border-radius: var(--radius-lg);
      overflow: hidden;
      box-shadow: var(--shadow-md);
    }

    .table-header {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr 1.5fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      font-weight: 600;
      color: var(--text-primary);
      border-bottom: 1px solid var(--border-color);
    }

    .table-row {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr 1.5fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      border-bottom: 1px solid var(--border-light);
      align-items: center;
    }

    .table-row:last-child {
      border-bottom: none;
    }

    .table-row:hover {
      background: var(--bg-tertiary);
    }

    .exam-name {
      font-weight: 500;
      color: var(--text-primary);
    }

    .score {
      font-weight: 600;
      color: var(--primary-color);
    }

    .percentage {
      font-weight: 600;
    }

    .badge-completed {
      background: rgb(34 197 94 / 0.1);
      color: var(--success-color);
    }

    .badge-in_progress {
      background: rgb(249 115 22 / 0.1);
      color: var(--warning-color);
    }

    .badge-terminated {
      background: rgb(239 68 68 / 0.1);
      color: var(--error-color);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
    }

    .stat-card {
      padding: var(--spacing-xl);
      display: flex;
      align-items: center;
      gap: var(--spacing-lg);
    }

    .stat-icon {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.5rem;
    }

    .stat-content {
      flex: 1;
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1;
    }

    .stat-label {
      color: var(--text-secondary);
      font-size: 0.875rem;
      margin-top: var(--spacing-xs);
    }

    .empty-state {
      text-align: center;
      padding: var(--spacing-2xl);
      color: var(--text-secondary);
    }

    .empty-state .material-icons {
      font-size: 4rem;
      color: var(--text-muted);
      margin-bottom: var(--spacing-lg);
    }

    .empty-state h3 {
      font-size: 1.25rem;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    @media (max-width: 768px) {
      .student-dashboard {
        padding: var(--spacing-lg);
      }

      .exams-grid {
        grid-template-columns: 1fr;
      }

      .table-header,
      .table-row {
        grid-template-columns: 1fr;
        gap: var(--spacing-sm);
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class StudentDashboardComponent implements OnInit {
  availableExams: Exam[] = [];
  recentSessions: ExamSession[] = [];
  performanceStats = {
    totalExams: 0,
    averageScore: 0,
    highestScore: 0,
    upcomingExams: 0
  };

  constructor(private examService: ExamService) {}

  ngOnInit(): void {
    this.loadAvailableExams();
    this.loadRecentSessions();
    this.loadPerformanceStats();
  }

  private loadAvailableExams(): void {
    // Mock data for student exams
    this.availableExams = [
      {
        id: 1,
        title: 'Mathematics Final Exam',
        description: 'Comprehensive mathematics exam covering algebra and calculus',
        duration: 120,
        totalMarks: 100,
        startTime: new Date(),
        endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        randomizeQuestions: false,
        active: true,
        instructor: { name: 'Dr. Smith' },
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date('2024-01-15'),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: 'Programming Quiz',
        description: 'Quick assessment on programming fundamentals',
        duration: 45,
        totalMarks: 50,
        startTime: new Date(),
        endTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        randomizeQuestions: true,
        active: true,
        instructor: { name: 'Prof. Johnson' },
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date('2024-02-01'),
        updatedAt: new Date()
      }
    ];
    this.performanceStats.upcomingExams = this.availableExams.length;
  }

  private loadRecentSessions(): void {
    // Load from localStorage or use mock data
    const storedSessions = localStorage.getItem('studentExamSessions');
    if (storedSessions) {
      this.recentSessions = JSON.parse(storedSessions).map((session: any) => ({
        ...session,
        startTime: new Date(session.startTime),
        endTime: new Date(session.endTime),
        submittedAt: new Date(session.submittedAt)
      }));
    } else {
      // Mock data for recent sessions
      this.recentSessions = [
        {
          id: 1,
          exam: {
            id: 1,
            title: 'Physics Quiz',
            description: 'Physics assessment',
            duration: 45,
            totalMarks: 50,
            startTime: new Date(),
            endTime: new Date(),
            randomizeQuestions: false,
            active: true,
            instructor: null,
            questions: [],
            assignedStudents: [],
            examSessions: [],
            createdAt: new Date(),
            updatedAt: new Date()
          } as Exam,
          student: null,
          startTime: new Date('2024-01-20T10:00:00'),
          endTime: new Date('2024-01-20T10:45:00'),
          submittedAt: new Date('2024-01-20T10:42:00'),
          status: 'COMPLETED' as any,
          score: 42,
          percentage: 84,
          ipAddress: '',
          userAgent: '',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: 2,
          exam: {
            id: 2,
            title: 'Chemistry Test',
            description: 'Chemistry assessment',
            duration: 60,
            totalMarks: 75,
            startTime: new Date(),
            endTime: new Date(),
            randomizeQuestions: false,
            active: true,
            instructor: null,
            questions: [],
            assignedStudents: [],
            examSessions: [],
            createdAt: new Date(),
            updatedAt: new Date()
          } as Exam,
          student: null,
          startTime: new Date('2024-01-18T14:00:00'),
          endTime: new Date('2024-01-18T15:00:00'),
          submittedAt: new Date('2024-01-18T14:58:00'),
          status: 'COMPLETED' as any,
          score: 68,
          percentage: 90.7,
          ipAddress: '',
          userAgent: '',
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ];
      // Store initial data
      localStorage.setItem('studentExamSessions', JSON.stringify(this.recentSessions));
    }
  }

  private loadPerformanceStats(): void {
    // Calculate stats from recent sessions
    if (this.recentSessions.length > 0) {
      const totalScore = this.recentSessions.reduce((sum, session) => sum + (session.percentage || 0), 0);
      const averageScore = Math.round(totalScore / this.recentSessions.length);
      const highestScore = Math.max(...this.recentSessions.map(session => session.percentage || 0));
      
      this.performanceStats = {
        totalExams: this.recentSessions.length,
        averageScore: averageScore,
        highestScore: Math.round(highestScore),
        upcomingExams: this.availableExams.length
      };
    } else {
      // Default stats if no sessions
      this.performanceStats = {
        totalExams: 0,
        averageScore: 0,
        highestScore: 0,
        upcomingExams: this.availableExams.length
      };
    }
  }

  formatDate(date: Date | string | null): string {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  }

  getStatusClass(status: string): string {
    return `badge-${status.toLowerCase()}`;
  }

  addExamResult(examResult: ExamSession): void {
    this.recentSessions.unshift(examResult);
    localStorage.setItem('studentExamSessions', JSON.stringify(this.recentSessions));
    this.loadPerformanceStats();
  }
}