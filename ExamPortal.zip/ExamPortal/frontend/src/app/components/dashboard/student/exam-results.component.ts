import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ExamService } from '../../../services/exam.service';
import { ExamSession, Exam, Question } from '../../../models/exam.model';

@Component({
  selector: 'app-exam-results',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="results-container fade-in" *ngIf="session">
      <div class="results-header">
        <div class="back-button">
          <button class="btn btn-secondary" routerLink="/student">
            <span class="material-icons">arrow_back</span>
            Back to Dashboard
          </button>
        </div>
        
        <div class="exam-info">
          <h1>{{ session.exam.title }}</h1>
          <p>{{ session.exam.description }}</p>
        </div>
      </div>

      <div class="results-content">
        <!-- Score Overview -->
        <div class="score-section card">
          <div class="score-header">
            <h2>Your Results</h2>
            <div class="completion-status" [class]="getStatusClass(session.status)">
              {{ session.status }}
            </div>
          </div>
          
          <div class="score-display">
            <div class="score-circle" [class]="getScoreClass(session.percentage || 0)">
              <div class="score-value">{{ session.percentage | number:'1.0-0' }}%</div>
              <div class="score-label">Overall Score</div>
            </div>
            
            <div class="score-details">
              <div class="detail-row">
                <span>Points Earned:</span>
                <span class="value">{{ session.score }} / {{ session.exam.totalMarks }}</span>
              </div>
              <div class="detail-row">
                <span>Questions:</span>
                <span class="value">{{ session.exam.questions.length || 0 }}</span>
              </div>
              <div class="detail-row">
                <span>Time Taken:</span>
                <span class="value">{{ calculateTimeTaken() }}</span>
              </div>
              <div class="detail-row">
                <span>Submitted:</span>
                <span class="value">{{ formatDateTime(session.submittedAt) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Performance Analysis -->
        <div class="analysis-section card">
          <h2>Performance Analysis</h2>
          
          <div class="performance-grid">
            <div class="performance-item">
              <div class="performance-icon excellent">
                <span class="material-icons">emoji_events</span>
              </div>
              <div class="performance-content">
                <h3>{{ getCorrectAnswers() }} Correct</h3>
                <p>Out of {{ session.exam.questions.length || 0 }} questions</p>
              </div>
            </div>
            
            <div class="performance-item">
              <div class="performance-icon good">
                <span class="material-icons">speed</span>
              </div>
              <div class="performance-content">
                <h3>{{ getAverageTimePerQuestion() }}</h3>
                <p>Average time per question</p>
              </div>
            </div>
            
            <div class="performance-item">
              <div class="performance-icon" [class]="getDifficultyClass()">
                <span class="material-icons">trending_up</span>
              </div>
              <div class="performance-content">
                <h3>{{ getDifficultyLevel() }}</h3>
                <p>Performance level</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Grade Breakdown -->
        <div class="breakdown-section card">
          <h2>Grade Breakdown</h2>
          
          <div class="grade-chart">
            <div class="grade-bar">
              <div class="grade-fill" [style.width.%]="session.percentage"></div>
            </div>
            <div class="grade-markers">
              <div class="marker" style="left: 0%">0%</div>
              <div class="marker" style="left: 25%">25%</div>
              <div class="marker" style="left: 50%">50%</div>
              <div class="marker" style="left: 75%">75%</div>
              <div class="marker" style="left: 100%">100%</div>
            </div>
          </div>
          
          <div class="grade-feedback">
            <div class="feedback-item" [class]="getFeedbackClass()">
              <span class="material-icons">{{ getFeedbackIcon() }}</span>
              <div>
                <h4>{{ getFeedbackTitle() }}</h4>
                <p>{{ getFeedbackMessage() }}</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Actions -->
        <div class="actions-section">
          <button class="btn btn-primary" routerLink="/student">
            <span class="material-icons">dashboard</span>
            Return to Dashboard
          </button>
          <button class="btn btn-secondary" (click)="downloadResults()">
            <span class="material-icons">download</span>
            Download Results
          </button>
        </div>
      </div>
    </div>

    <div *ngIf="!session" class="loading-container">
      <div class="spinner"></div>
      <p>Loading results...</p>
    </div>
  `,
  styles: [`
    .results-container {
      min-height: 100vh;
      background: var(--bg-secondary);
      padding: var(--spacing-xl);
    }

    .results-header {
      max-width: 800px;
      margin: 0 auto var(--spacing-2xl);
    }

    .back-button {
      margin-bottom: var(--spacing-lg);
    }

    .exam-info {
      text-align: center;
    }

    .exam-info h1 {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .exam-info p {
      color: var(--text-secondary);
      font-size: 1.125rem;
    }

    .results-content {
      max-width: 800px;
      margin: 0 auto;
    }

    .card {
      margin-bottom: var(--spacing-xl);
      padding: var(--spacing-2xl);
    }

    .score-section h2,
    .analysis-section h2,
    .breakdown-section h2 {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-xl);
    }

    .score-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-xl);
    }

    .completion-status {
      padding: var(--spacing-sm) var(--spacing-lg);
      border-radius: var(--radius-md);
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.875rem;
    }

    .completion-status.completed {
      background: rgb(34 197 94 / 0.1);
      color: var(--success-color);
    }

    .score-display {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: var(--spacing-2xl);
      align-items: center;
    }

    .score-circle {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      position: relative;
      border: 8px solid;
    }

    .score-circle.excellent {
      border-color: var(--success-color);
      background: rgb(34 197 94 / 0.1);
    }

    .score-circle.good {
      border-color: var(--primary-color);
      background: rgb(99 102 241 / 0.1);
    }

    .score-circle.average {
      border-color: var(--warning-color);
      background: rgb(249 115 22 / 0.1);
    }

    .score-circle.poor {
      border-color: var(--error-color);
      background: rgb(239 68 68 / 0.1);
    }

    .score-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .score-label {
      font-size: 0.875rem;
      color: var(--text-secondary);
      margin-top: var(--spacing-xs);
    }

    .score-details {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-lg);
    }

    .detail-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: var(--spacing-md) 0;
      border-bottom: 1px solid var(--border-light);
    }

    .detail-row:last-child {
      border-bottom: none;
    }

    .detail-row .value {
      font-weight: 600;
      color: var(--text-primary);
    }

    .performance-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
    }

    .performance-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-lg);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      border-radius: var(--radius-lg);
    }

    .performance-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }

    .performance-icon.excellent {
      background: var(--success-color);
    }

    .performance-icon.good {
      background: var(--primary-color);
    }

    .performance-icon.average {
      background: var(--warning-color);
    }

    .performance-icon.poor {
      background: var(--error-color);
    }

    .performance-content h3 {
      font-size: 1.125rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-xs);
    }

    .performance-content p {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .grade-chart {
      margin-bottom: var(--spacing-xl);
    }

    .grade-bar {
      height: 20px;
      background: var(--bg-tertiary);
      border-radius: var(--radius-md);
      overflow: hidden;
      position: relative;
    }

    .grade-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--error-color) 0%, var(--warning-color) 50%, var(--success-color) 100%);
      transition: width 1s ease-out;
    }

    .grade-markers {
      display: flex;
      justify-content: space-between;
      margin-top: var(--spacing-sm);
      position: relative;
    }

    .marker {
      font-size: 0.75rem;
      color: var(--text-secondary);
      position: absolute;
      transform: translateX(-50%);
    }

    .grade-feedback {
      background: var(--bg-tertiary);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
    }

    .feedback-item {
      display: flex;
      align-items: flex-start;
      gap: var(--spacing-md);
    }

    .feedback-item .material-icons {
      font-size: 2rem;
    }

    .feedback-item.excellent .material-icons {
      color: var(--success-color);
    }

    .feedback-item.good .material-icons {
      color: var(--primary-color);
    }

    .feedback-item.average .material-icons {
      color: var(--warning-color);
    }

    .feedback-item.poor .material-icons {
      color: var(--error-color);
    }

    .feedback-item h4 {
      font-size: 1.125rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-xs);
    }

    .feedback-item p {
      color: var(--text-secondary);
      line-height: 1.6;
    }

    .actions-section {
      display: flex;
      gap: var(--spacing-md);
      justify-content: center;
      margin-top: var(--spacing-2xl);
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      gap: var(--spacing-lg);
    }

    @media (max-width: 768px) {
      .results-container {
        padding: var(--spacing-lg);
      }

      .score-display {
        grid-template-columns: 1fr;
        text-align: center;
      }

      .performance-grid {
        grid-template-columns: 1fr;
      }

      .actions-section {
        flex-direction: column;
      }
    }
  `]
})
export class ExamResultsComponent implements OnInit {
  session: ExamSession | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private examService: ExamService
  ) {}

  ngOnInit(): void {
    const sessionId = this.route.snapshot.params['id'];
    this.loadResults(sessionId);
  }

  private loadResults(sessionId: number): void {
    // Get data from navigation state or use mock data
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state;
    
    this.session = {
      id: sessionId,
      exam: {
        id: 1,
        title: 'Mathematics Final Exam',
        description: 'Comprehensive mathematics exam',
        duration: 60,
        totalMarks: 100,
        startTime: new Date(),
        endTime: new Date(),
        randomizeQuestions: false,
        active: true,
        instructor: null,
        questions: [],
        assignedStudents: [],
        examSessions: [],
        createdAt: new Date(),
        updatedAt: new Date()
      } as Exam,
      student: null,
      startTime: new Date(Date.now() - 3600000), // 1 hour ago
      endTime: new Date(Date.now() - 600000), // 10 minutes ago
      submittedAt: new Date(Date.now() - 600000),
      status: 'COMPLETED' as any,
      score: (state as any)?.score || 85,
      percentage: (state as any)?.percentage || 85,
      ipAddress: '127.0.0.1',
      userAgent: navigator.userAgent,
      createdAt: new Date(),
      updatedAt: new Date()
    };
  }

  getStatusClass(status: string): string {
    return status.toLowerCase();
  }

  getScoreClass(percentage: number): string {
    if (percentage >= 90) return 'excellent';
    if (percentage >= 75) return 'good';
    if (percentage >= 60) return 'average';
    return 'poor';
  }

  calculateTimeTaken(): string {
    if (!this.session?.startTime || !this.session?.submittedAt) return 'N/A';
    
    const start = new Date(this.session.startTime);
    const end = new Date(this.session.submittedAt);
    const diffMs = end.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    return `${diffMins} minutes`;
  }

  formatDateTime(date: Date | string | null): string {
    if (!date) return 'N/A';
    return new Date(date).toLocaleString();
  }

  getCorrectAnswers(): number {
    // This would be calculated from actual answer data
    return Math.floor((this.session?.percentage || 0) / 100 * (this.session?.exam.questions?.length || 0));
  }

  getAverageTimePerQuestion(): string {
    if (!this.session?.startTime || !this.session?.submittedAt) return 'N/A';
    
    const totalTime = new Date(this.session.submittedAt).getTime() - new Date(this.session.startTime).getTime();
    const avgTime = totalTime / (this.session.exam.questions?.length || 1) / 60000;
    
    return `${avgTime.toFixed(1)} min`;
  }

  getDifficultyLevel(): string {
    const percentage = this.session?.percentage || 0;
    if (percentage >= 90) return 'Excellent';
    if (percentage >= 75) return 'Good';
    if (percentage >= 60) return 'Average';
    return 'Needs Improvement';
  }

  getDifficultyClass(): string {
    const percentage = this.session?.percentage || 0;
    if (percentage >= 90) return 'excellent';
    if (percentage >= 75) return 'good';
    if (percentage >= 60) return 'average';
    return 'poor';
  }

  getFeedbackClass(): string {
    return this.getScoreClass(this.session?.percentage || 0);
  }

  getFeedbackIcon(): string {
    const percentage = this.session?.percentage || 0;
    if (percentage >= 90) return 'emoji_events';
    if (percentage >= 75) return 'thumb_up';
    if (percentage >= 60) return 'trending_up';
    return 'trending_down';
  }

  getFeedbackTitle(): string {
    const percentage = this.session?.percentage || 0;
    if (percentage >= 90) return 'Outstanding Performance!';
    if (percentage >= 75) return 'Great Job!';
    if (percentage >= 60) return 'Good Effort!';
    return 'Keep Practicing!';
  }

  getFeedbackMessage(): string {
    const percentage = this.session?.percentage || 0;
    if (percentage >= 90) return 'You demonstrated excellent understanding of the material. Keep up the outstanding work!';
    if (percentage >= 75) return 'You showed good grasp of the concepts. Continue building on this solid foundation.';
    if (percentage >= 60) return 'You have a basic understanding. Review the material and practice more to improve.';
    return 'Consider reviewing the study materials and seeking additional help to strengthen your understanding.';
  }

  downloadResults(): void {
    // Implementation for downloading results as PDF
    console.log('Downloading results...');
  }
}