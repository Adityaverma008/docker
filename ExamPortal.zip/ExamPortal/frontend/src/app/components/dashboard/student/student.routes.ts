import { Routes } from '@angular/router';

export const studentRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./student-dashboard.component').then(m => m.StudentDashboardComponent)
  },
  {
    path: 'results/:id',
    loadComponent: () => import('./exam-results.component').then(m => m.ExamResultsComponent)
  }
];