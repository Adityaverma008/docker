import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserManagementService } from '../../../services/user-management.service';
import { StudentProgressService } from '../../../services/student-progress.service';
import { User, UserRole, RegisterRequest } from '../../../models/user.model';
import { NavbarComponent } from '../../shared/navbar.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="admin-dashboard fade-in">
      <!-- Header -->
      <div class="dashboard-header">
        <div class="header-content">
          <div class="header-text">
            <h1>Admin Control Center</h1>
            <p>Complete system management and control</p>
          </div>
          <div class="header-image">
            <div class="admin-avatar">
              <span class="material-icons">admin_panel_settings</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Stats Overview -->
      <div class="stats-section">
        <div class="stats-grid">
          <div class="stat-card card scale-in" style="animation-delay: 0.1s">
            <div class="stat-icon users">
              <span class="material-icons">people</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalUsers }}</div>
              <div class="stat-label">Total Users</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.2s">
            <div class="stat-icon exams">
              <span class="material-icons">quiz</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalExams }}</div>
              <div class="stat-label">Active Exams</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.3s">
            <div class="stat-icon sessions">
              <span class="material-icons">assignment</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.totalSessions }}</div>
              <div class="stat-label">Exam Sessions</div>
            </div>
          </div>
          
          <div class="stat-card card scale-in" style="animation-delay: 0.4s">
            <div class="stat-icon violations">
              <span class="material-icons">warning</span>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ stats.violations }}</div>
              <div class="stat-label">Violations</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content -->
      <div class="main-content">
        <!-- User Management -->
        <div class="management-section card slide-up">
          <div class="section-header">
            <h2>
              <span class="material-icons">group_add</span>
              User Management
            </h2>
            <button class="btn btn-primary" (click)="toggleCreateUser()">
              <span class="material-icons">add</span>
              Create User
            </button>
          </div>

          <!-- Create User Form -->
          <div class="create-user-form" *ngIf="showCreateForm">
            <form [formGroup]="createUserForm" (ngSubmit)="createUser()">
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">First Name</label>
                  <input type="text" formControlName="firstName" class="form-input" placeholder="Enter first name">
                </div>
                <div class="form-group">
                  <label class="form-label">Last Name</label>
                  <input type="text" formControlName="lastName" class="form-input" placeholder="Enter last name">
                </div>
                <div class="form-group">
                  <label class="form-label">Username</label>
                  <input type="text" formControlName="username" class="form-input" placeholder="Enter username">
                </div>
                <div class="form-group">
                  <label class="form-label">Email</label>
                  <input type="email" formControlName="email" class="form-input" placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label class="form-label">Password</label>
                  <input type="password" formControlName="password" class="form-input" placeholder="Enter password">
                </div>
                <div class="form-group">
                  <label class="form-label">Role</label>
                  <select formControlName="role" class="form-input">
                    <option value="STUDENT">Student</option>
                    <option value="INSTRUCTOR">Instructor</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                </div>
              </div>
              <div class="form-actions">
                <button type="button" class="btn btn-secondary" (click)="toggleCreateUser()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="createUserForm.invalid || isCreating">
                  <span *ngIf="isCreating" class="spinner"></span>
                  {{ isCreating ? 'Creating...' : 'Create User' }}
                </button>
              </div>
            </form>
          </div>

          <!-- Users List -->
          <div class="users-list">
            <div class="list-header">
              <div>Name</div>
              <div>Username</div>
              <div>Email</div>
              <div>Role</div>
              <div>Status</div>
              <div>Actions</div>
            </div>
            <div *ngFor="let user of users" class="list-row">
              <div class="user-name">
                <div class="user-avatar">
                  <span class="material-icons">person</span>
                </div>
                <div>
                  <div class="name">{{ user.firstName }} {{ user.lastName }}</div>
                  <div class="created">Created {{ formatDate(user.createdAt) }}</div>
                </div>
              </div>
              <div class="username">{{ user.username }}</div>
              <div class="email">{{ user.email }}</div>
              <div class="role">
                <span class="badge" [class]="'badge-' + user.role.toLowerCase()">{{ user.role }}</span>
              </div>
              <div class="status">
                <span class="badge" [class]="user.enabled ? 'badge-success' : 'badge-error'">
                  {{ user.enabled ? 'Active' : 'Inactive' }}
                </span>
              </div>
              <div class="actions">
                <button class="btn btn-sm btn-secondary" (click)="editUser(user)">
                  <span class="material-icons">edit</span>
                </button>
                <button class="btn btn-sm btn-error" (click)="deleteUser(user.id)">
                  <span class="material-icons">delete</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Student Progress Overview -->
        <div class="progress-overview-section card slide-up" style="animation-delay: 0.2s">
          <div class="section-header">
            <h2>
              <span class="material-icons">trending_up</span>
              Student Progress Overview
            </h2>
            <button class="btn btn-primary" routerLink="/student-progress">
              <span class="material-icons">analytics</span>
              View Detailed Progress
            </button>
          </div>
          
          <div class="progress-summary">
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">people</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.totalStudents }}</div>
                <div class="summary-label">Active Students</div>
              </div>
            </div>
            
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">assignment_turned_in</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.averageCompletion }}%</div>
                <div class="summary-label">Avg Completion</div>
              </div>
            </div>
            
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">grade</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.averageScore }}%</div>
                <div class="summary-label">Avg Score</div>
              </div>
            </div>
            
            <div class="summary-card">
              <div class="summary-icon">
                <span class="material-icons">warning</span>
              </div>
              <div class="summary-content">
                <div class="summary-value">{{ progressSummary.totalViolations }}</div>
                <div class="summary-label">Total Violations</div>
              </div>
            </div>
          </div>
        </div>

        <!-- System Analytics -->
        <div class="analytics-section card slide-up" style="animation-delay: 0.3s">
          <div class="section-header">
            <h2>
              <span class="material-icons">analytics</span>
              System Analytics
            </h2>
          </div>
          
          <div class="analytics-grid">
            <div class="analytics-item">
              <h3>User Distribution</h3>
              <div class="chart-placeholder">
                <div class="pie-chart">
                  <div class="chart-segment admin" style="--percentage: 10"></div>
                  <div class="chart-segment instructor" style="--percentage: 20"></div>
                  <div class="chart-segment student" style="--percentage: 70"></div>
                </div>
                <div class="chart-legend">
                  <div class="legend-item">
                    <div class="legend-color admin"></div>
                    <span>Admins (10%)</span>
                  </div>
                  <div class="legend-item">
                    <div class="legend-color instructor"></div>
                    <span>Instructors (20%)</span>
                  </div>
                  <div class="legend-item">
                    <div class="legend-color student"></div>
                    <span>Students (70%)</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="analytics-item">
              <h3>Recent Activity</h3>
              <div class="activity-list">
                <div class="activity-item">
                  <span class="material-icons">person_add</span>
                  <div>
                    <div>New user registered</div>
                    <div class="time">2 minutes ago</div>
                  </div>
                </div>
                <div class="activity-item">
                  <span class="material-icons">quiz</span>
                  <div>
                    <div>Exam completed</div>
                    <div class="time">5 minutes ago</div>
                  </div>
                </div>
                <div class="activity-item">
                  <span class="material-icons">warning</span>
                  <div>
                    <div>Violation detected</div>
                    <div class="time">10 minutes ago</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .admin-dashboard {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: var(--spacing-xl);
    }

    .dashboard-header {
      margin-bottom: var(--spacing-2xl);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .header-text h1 {
      font-size: 3rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
      background: linear-gradient(135deg, #667eea, #764ba2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-text p {
      font-size: 1.25rem;
      color: var(--text-secondary);
    }

    .admin-avatar {
      width: 100px;
      height: 100px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 3rem;
      animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
    }

    .stats-section {
      margin-bottom: var(--spacing-2xl);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
    }

    .stat-card {
      padding: var(--spacing-xl);
      display: flex;
      align-items: center;
      gap: var(--spacing-lg);
      background: var(--bg-card);
      transition: all 0.3s ease;
    }

    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: var(--shadow-xl);
    }

    .stat-icon {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.5rem;
    }

    .stat-icon.users { background: linear-gradient(135deg, #667eea, #764ba2); }
    .stat-icon.exams { background: linear-gradient(135deg, #f093fb, #f5576c); }
    .stat-icon.sessions { background: linear-gradient(135deg, #4facfe, #00f2fe); }
    .stat-icon.violations { background: linear-gradient(135deg, #43e97b, #38f9d7); }

    .stat-value {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .stat-label {
      color: var(--text-secondary);
      font-weight: 500;
    }

    .main-content {
      display: grid;
      gap: var(--spacing-2xl);
    }

    .management-section,
    .analytics-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-xl);
      padding-bottom: var(--spacing-lg);
      border-bottom: 2px solid var(--border-color);
    }

    .section-header h2 {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .create-user-form {
      background: var(--bg-tertiary);
      padding: var(--spacing-xl);
      border-radius: var(--radius-lg);
      margin-bottom: var(--spacing-xl);
    }

    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-lg);
      margin-bottom: var(--spacing-xl);
    }

    .form-actions {
      display: flex;
      gap: var(--spacing-md);
      justify-content: flex-end;
    }

    .users-list {
      background: var(--bg-primary);
      border-radius: var(--radius-lg);
      overflow: hidden;
    }

    .list-header {
      display: grid;
      grid-template-columns: 2fr 1fr 2fr 1fr 1fr 1fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      font-weight: 600;
      color: var(--text-primary);
    }

    .list-row {
      display: grid;
      grid-template-columns: 2fr 1fr 2fr 1fr 1fr 1fr;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      border-bottom: 1px solid var(--border-light);
      align-items: center;
      transition: all 0.3s ease;
    }

    .list-row:hover {
      background: var(--bg-tertiary);
    }

    .user-name {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      background: var(--primary-color);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }

    .name {
      font-weight: 500;
      color: var(--text-primary);
    }

    .created {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .badge-admin { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
    .badge-instructor { background: linear-gradient(135deg, #f093fb, #f5576c); color: white; }
    .badge-student { background: linear-gradient(135deg, #4facfe, #00f2fe); color: white; }

    .actions {
      display: flex;
      gap: var(--spacing-sm);
    }

    .analytics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: var(--spacing-xl);
    }

    .analytics-item h3 {
      margin-bottom: var(--spacing-lg);
      color: var(--text-primary);
    }

    .chart-placeholder {
      display: flex;
      align-items: center;
      gap: var(--spacing-xl);
    }

    .pie-chart {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: conic-gradient(
        #667eea 0deg 36deg,
        #f093fb 36deg 108deg,
        #4facfe 108deg 360deg
      );
    }

    .chart-legend {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-sm);
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }

    .legend-color {
      width: 16px;
      height: 16px;
      border-radius: 50%;
    }

    .legend-color.admin { background: #667eea; }
    .legend-color.instructor { background: #f093fb; }
    .legend-color.student { background: #4facfe; }

    .activity-list {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-md);
    }

    .activity-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      padding: var(--spacing-md);
      background: var(--bg-tertiary);
      border-radius: var(--radius-md);
    }

    .activity-item .material-icons {
      color: var(--primary-color);
    }

    .time {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .progress-overview-section {
      background: var(--bg-card);
      padding: var(--spacing-2xl);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-xl);
    }

    .progress-summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: var(--spacing-lg);
    }

    .summary-card {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      padding: var(--spacing-lg);
      background: var(--bg-tertiary);
      border-radius: var(--radius-lg);
      transition: all 0.3s ease;
    }

    .summary-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }

    .summary-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.25rem;
      background: linear-gradient(135deg, #667eea, #764ba2);
    }

    .summary-value {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .summary-label {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    @media (max-width: 768px) {
      .admin-dashboard {
        padding: var(--spacing-lg);
      }

      .header-content {
        flex-direction: column;
        text-align: center;
        gap: var(--spacing-lg);
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }

      .list-header,
      .list-row {
        grid-template-columns: 1fr;
        gap: var(--spacing-sm);
      }

      .form-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  showCreateForm = false;
  isCreating = false;
  createUserForm: FormGroup;
  users: User[] = [];
  stats = {
    totalUsers: 156,
    totalExams: 24,
    totalSessions: 342,
    violations: 8
  };

  progressSummary = {
    totalStudents: 0,
    averageCompletion: 0,
    averageScore: 0,
    totalViolations: 0
  };

  constructor(
    private fb: FormBuilder,
    private userManagementService: UserManagementService,
    private studentProgressService: StudentProgressService
  ) {
    this.createUserForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: [UserRole.STUDENT, Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadUsers();
    this.loadProgressSummary();
  }

  toggleCreateUser(): void {
    this.showCreateForm = !this.showCreateForm;
    if (!this.showCreateForm) {
      this.createUserForm.reset();
    }
  }

  createUser(): void {
    if (this.createUserForm.valid) {
      this.isCreating = true;
      const userData: RegisterRequest = this.createUserForm.value;
      
      this.userManagementService.createUser(userData).subscribe({
        next: (response) => {
          // Add new user to local array for immediate display
          const newUser: User = {
            id: Date.now(),
            username: userData.username,
            email: userData.email,
            firstName: userData.firstName,
            lastName: userData.lastName,
            role: userData.role,
            enabled: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            phone: userData.phone || ''
          };
          this.users.unshift(newUser);
          
          this.isCreating = false;
          this.showCreateForm = false;
          this.createUserForm.reset();
        },
        error: (error) => {
          // Still add to local array even if API fails (for demo)
          const newUser: User = {
            id: Date.now(),
            username: userData.username,
            email: userData.email,
            firstName: userData.firstName,
            lastName: userData.lastName,
            role: userData.role,
            enabled: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            phone: userData.phone || ''
          };
          this.users.unshift(newUser);
          
          this.isCreating = false;
          this.showCreateForm = false;
          this.createUserForm.reset();
        }
      });
    }
  }

  loadUsers(): void {
    this.userManagementService.getAllUsers().subscribe({
      next: (users) => {
        this.users = users;
      },
      error: (error) => {
        // Fallback to mock data if API fails
        this.users = [
          {
            id: 1,
            username: 'Addy',
            email: 'aditya@examportal.com',
            firstName: 'Aditya',
            lastName: 'Verma',
            role: UserRole.ADMIN,
            enabled: true,
            createdAt: new Date('2024-01-01'),
            updatedAt: new Date(),
            phone: ''
          },
          {
            id: 2,
            username: 'john_instructor',
            email: 'john@examportal.com',
            firstName: 'John',
            lastName: 'Smith',
            role: UserRole.INSTRUCTOR,
            enabled: true,
            createdAt: new Date('2024-01-15'),
            updatedAt: new Date(),
            phone: ''
          },
          {
            id: 3,
            username: 'alice_student',
            email: 'alice@examportal.com',
            firstName: 'Alice',
            lastName: 'Johnson',
            role: UserRole.STUDENT,
            enabled: true,
            createdAt: new Date('2024-02-01'),
            updatedAt: new Date(),
            phone: ''
          }
        ];
      }
    });
  }

  editUser(user: User): void {
    console.log('Edit user:', user);
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      console.log('Delete user:', userId);
    }
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString();
  }

  loadProgressSummary(): void {
    this.studentProgressService.getProgressSummary().subscribe(summary => {
      this.progressSummary = summary;
    });
  }
}