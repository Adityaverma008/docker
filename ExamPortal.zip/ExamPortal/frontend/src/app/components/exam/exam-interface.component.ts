import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Subscription, interval } from 'rxjs';
import { ExamService } from '../../services/exam.service';
import { ProctoringService } from '../../services/proctoring.service';
import { Exam, ExamSession, Question, SessionStatus } from '../../models/exam.model';
import { EventType, SeverityLevel } from '../../models/proctoring.model';

@Component({
  selector: 'app-exam-interface',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="exam-container" *ngIf="exam && session">
      <!-- Exam Header -->
      <div class="exam-header">
        <div class="exam-info">
          <h1>{{ exam.title }}</h1>
          <p>{{ exam.description }}</p>
        </div>
        <div class="exam-timer" [class.warning]="timeRemaining < 300">
          <span class="material-icons">timer</span>
          <span class="timer-text">{{ formatTime(timeRemaining) }}</span>
        </div>
      </div>

      <!-- Proctoring Panel -->
      <div class="proctoring-panel" *ngIf="isProctoringActive">
        <div class="webcam-container">
          <video #webcamVideo autoplay muted class="webcam-feed"></video>
          <div class="proctoring-status" [class]="proctoringStatus.type">
            <span class="material-icons">{{ proctoringStatus.icon }}</span>
            <span>{{ proctoringStatus.message }}</span>
          </div>
        </div>
        
        <div class="violation-alerts" *ngIf="violations.length > 0">
          <div *ngFor="let violation of violations" class="violation-alert" [class]="violation.severity.toLowerCase()">
            <span class="material-icons">warning</span>
            <span>{{ violation.description }}</span>
          </div>
        </div>
      </div>

      <!-- Question Navigation -->
      <div class="question-nav">
        <div class="nav-buttons">
          <button 
            class="btn btn-secondary" 
            (click)="previousQuestion()" 
            [disabled]="currentQuestionIndex === 0">
            <span class="material-icons">chevron_left</span>
            Previous
          </button>
          <span class="question-counter">
            Question {{ currentQuestionIndex + 1 }} of {{ questions.length }}
          </span>
          <button 
            class="btn btn-secondary" 
            (click)="nextQuestion()" 
            [disabled]="currentQuestionIndex === questions.length - 1">
            Next
            <span class="material-icons">chevron_right</span>
          </button>
        </div>
        
        <div class="question-grid">
          <button 
            *ngFor="let q of questions; let i = index"
            class="question-btn"
            [class.current]="i === currentQuestionIndex"
            [class.answered]="isQuestionAnswered(i)"
            (click)="goToQuestion(i)">
            {{ i + 1 }}
          </button>
        </div>
      </div>

      <!-- Question Content -->
      <div class="question-section card" *ngIf="currentQuestion">
        <div class="question-header">
          <h2>Question {{ currentQuestionIndex + 1 }}</h2>
          <span class="question-points">{{ currentQuestion.points }} points</span>
        </div>
        
        <div class="question-content" [innerHTML]="currentQuestion.content"></div>
        
        <form [formGroup]="answerForm" class="answer-section">
          <!-- MCQ Options -->
          <div *ngIf="currentQuestion.type === 'MCQ'" class="mcq-options">
            <div *ngFor="let option of currentQuestion.options; let i = index" class="option-item">
              <input 
                type="radio" 
                [id]="'option-' + i" 
                [value]="option" 
                formControlName="answer"
                (change)="saveAnswer()">
              <label [for]="'option-' + i">{{ option }}</label>
            </div>
          </div>

          <!-- Text Answer -->
          <div *ngIf="currentQuestion.type === 'SHORT_ANSWER' || currentQuestion.type === 'ESSAY'" class="text-answer">
            <textarea 
              formControlName="answer"
              [placeholder]="getAnswerPlaceholder()"
              [rows]="currentQuestion.type === 'ESSAY' ? 10 : 4"
              (input)="saveAnswer()"
              class="form-input"></textarea>
          </div>

          <!-- True/False -->
          <div *ngIf="currentQuestion.type === 'TRUE_FALSE'" class="tf-options">
            <div class="option-item">
              <input type="radio" id="true" value="True" formControlName="answer" (change)="saveAnswer()">
              <label for="true">True</label>
            </div>
            <div class="option-item">
              <input type="radio" id="false" value="False" formControlName="answer" (change)="saveAnswer()">
              <label for="false">False</label>
            </div>
          </div>
        </form>
      </div>

      <!-- Exam Actions -->
      <div class="exam-actions">
        <button class="btn btn-secondary" (click)="saveAndExit()">Save & Exit</button>
        <button class="btn btn-primary" (click)="submitExam()" [disabled]="isSubmitting">
          <span *ngIf="isSubmitting" class="spinner"></span>
          {{ isSubmitting ? 'Submitting...' : 'Submit Exam' }}
        </button>
      </div>
    </div>

    <!-- Loading State -->
    <div *ngIf="!exam || !session" class="loading-container">
      <div class="spinner"></div>
      <p>Loading exam...</p>
    </div>
  `,
  styles: [`
    .exam-container {
      min-height: 100vh;
      background: var(--bg-secondary);
      padding: var(--spacing-lg);
    }

    .exam-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-card);
      padding: var(--spacing-xl);
      border-radius: var(--radius-lg);
      margin-bottom: var(--spacing-lg);
      box-shadow: var(--shadow-md);
    }

    .exam-info h1 {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: var(--spacing-xs);
    }

    .exam-info p {
      color: var(--text-secondary);
    }

    .exam-timer {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      padding: var(--spacing-md);
      background: var(--success-color);
      color: white;
      border-radius: var(--radius-md);
      font-weight: 600;
      font-size: 1.125rem;
    }

    .exam-timer.warning {
      background: var(--error-color);
      animation: pulse 1s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.7; }
    }

    .proctoring-panel {
      background: var(--bg-card);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
      margin-bottom: var(--spacing-lg);
      box-shadow: var(--shadow-md);
    }

    .webcam-container {
      position: relative;
      display: inline-block;
    }

    .webcam-feed {
      width: 200px;
      height: 150px;
      border-radius: var(--radius-md);
      border: 2px solid var(--border-color);
    }

    .proctoring-status {
      position: absolute;
      bottom: var(--spacing-sm);
      left: var(--spacing-sm);
      right: var(--spacing-sm);
      background: rgba(0, 0, 0, 0.8);
      color: white;
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
      font-size: 0.75rem;
    }

    .proctoring-status.success {
      background: rgba(34, 197, 94, 0.9);
    }

    .proctoring-status.warning {
      background: rgba(249, 115, 22, 0.9);
    }

    .proctoring-status.error {
      background: rgba(239, 68, 68, 0.9);
    }

    .violation-alerts {
      margin-top: var(--spacing-md);
    }

    .violation-alert {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      padding: var(--spacing-sm) var(--spacing-md);
      border-radius: var(--radius-md);
      margin-bottom: var(--spacing-sm);
      font-size: 0.875rem;
    }

    .violation-alert.high {
      background: rgb(249 115 22 / 0.1);
      color: var(--warning-color);
      border: 1px solid rgb(249 115 22 / 0.2);
    }

    .violation-alert.critical {
      background: rgb(239 68 68 / 0.1);
      color: var(--error-color);
      border: 1px solid rgb(239 68 68 / 0.2);
    }

    .question-nav {
      background: var(--bg-card);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
      margin-bottom: var(--spacing-lg);
      box-shadow: var(--shadow-md);
    }

    .nav-buttons {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-lg);
    }

    .question-counter {
      font-weight: 600;
      color: var(--text-primary);
    }

    .question-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
      gap: var(--spacing-sm);
    }

    .question-btn {
      width: 40px;
      height: 40px;
      border: 1px solid var(--border-color);
      background: var(--bg-primary);
      color: var(--text-primary);
      border-radius: var(--radius-sm);
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 500;
    }

    .question-btn:hover {
      background: var(--primary-light);
      color: white;
    }

    .question-btn.current {
      background: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }

    .question-btn.answered {
      background: var(--success-color);
      color: white;
      border-color: var(--success-color);
    }

    .question-section {
      padding: var(--spacing-xl);
      margin-bottom: var(--spacing-lg);
    }

    .question-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-lg);
      padding-bottom: var(--spacing-lg);
      border-bottom: 1px solid var(--border-color);
    }

    .question-header h2 {
      color: var(--text-primary);
      font-weight: 600;
    }

    .question-points {
      background: var(--primary-color);
      color: white;
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      font-size: 0.875rem;
      font-weight: 500;
    }

    .question-content {
      font-size: 1.125rem;
      line-height: 1.6;
      color: var(--text-primary);
      margin-bottom: var(--spacing-xl);
    }

    .answer-section {
      margin-top: var(--spacing-xl);
    }

    .mcq-options, .tf-options {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-md);
    }

    .option-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-md);
      padding: var(--spacing-md);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .option-item:hover {
      background: var(--bg-tertiary);
      border-color: var(--primary-color);
    }

    .option-item input[type="radio"] {
      margin: 0;
    }

    .option-item label {
      cursor: pointer;
      flex: 1;
      margin: 0;
    }

    .text-answer textarea {
      width: 100%;
      resize: vertical;
    }

    .exam-actions {
      display: flex;
      justify-content: space-between;
      gap: var(--spacing-md);
      padding: var(--spacing-xl);
      background: var(--bg-card);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-md);
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      gap: var(--spacing-lg);
    }

    @media (max-width: 768px) {
      .exam-container {
        padding: var(--spacing-md);
      }

      .exam-header {
        flex-direction: column;
        gap: var(--spacing-md);
        text-align: center;
      }

      .nav-buttons {
        flex-direction: column;
        gap: var(--spacing-md);
      }

      .question-grid {
        grid-template-columns: repeat(auto-fill, minmax(35px, 1fr));
      }

      .exam-actions {
        flex-direction: column;
      }
    }
  `]
})
export class ExamInterfaceComponent implements OnInit, OnDestroy {
  exam: Exam | null = null;
  session: ExamSession | null = null;
  questions: Question[] = [];
  currentQuestionIndex = 0;
  currentQuestion: Question | null = null;
  answerForm: FormGroup;
  
  timeRemaining = 0;
  timerSubscription: Subscription | null = null;
  
  isProctoringActive = false;
  proctoringStatus = { type: 'success', icon: 'check_circle', message: 'Monitoring active' };
  violations: any[] = [];
  
  answers: Map<number, string> = new Map();
  isSubmitting = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private examService: ExamService,
    private proctoringService: ProctoringService,
    private fb: FormBuilder
  ) {
    this.answerForm = this.fb.group({
      answer: ['']
    });
  }

  ngOnInit(): void {
    const examId = this.route.snapshot.params['id'];
    this.loadExam(examId);
  }

  ngOnDestroy(): void {
    this.stopTimer();
    this.proctoringService.stopMonitoring();
  }

  private loadExam(examId: number): void {
    // Mock exam data for demonstration
    this.exam = {
      id: examId,
      title: 'Mathematics Final Exam',
      description: 'Comprehensive mathematics exam covering algebra and calculus',
      duration: 60, // 1 hour
      totalMarks: 100,
      startTime: new Date(),
      endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      randomizeQuestions: false,
      active: true,
      instructor: null,
      questions: [
        {
          id: 1,
          content: 'What is the derivative of x²?',
          type: 'SHORT_ANSWER' as any,
          difficulty: 'MEDIUM' as any,
          category: 'Mathematics',
          tags: 'calculus',
          points: 5,
          options: [],
          correctAnswer: '2x',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: 2,
          content: 'Which of the following is the correct formula for the area of a circle?',
          type: 'MCQ' as any,
          difficulty: 'EASY' as any,
          category: 'Mathematics',
          tags: 'geometry',
          points: 3,
          options: ['πr²', '2πr', 'πd', 'r²'],
          correctAnswer: 'πr²',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: 3,
          content: 'The square root of 16 is 4.',
          type: 'TRUE_FALSE' as any,
          difficulty: 'EASY' as any,
          category: 'Mathematics',
          tags: 'arithmetic',
          points: 2,
          options: ['True', 'False'],
          correctAnswer: 'True',
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      assignedStudents: [],
      examSessions: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.questions = this.exam.questions;
    this.currentQuestion = this.questions[0];
    this.startExam();
  }

  private startExam(): void {
    if (!this.exam) return;

    // Mock session for demonstration
    this.session = {
      id: Date.now(),
      exam: this.exam,
      student: null,
      startTime: new Date(),
      endTime: null,
      submittedAt: null,
      status: 'IN_PROGRESS' as any,
      score: null,
      percentage: null,
      ipAddress: '127.0.0.1',
      userAgent: navigator.userAgent,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.timeRemaining = this.exam.duration * 60; // Convert to seconds
    this.startTimer();
    this.initializeProctoring();
  }

  private startTimer(): void {
    this.timerSubscription = interval(1000).subscribe(() => {
      this.timeRemaining--;
      
      if (this.timeRemaining <= 0) {
        this.submitExam();
      }
    });
  }

  private stopTimer(): void {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
  }

  private async initializeProctoring(): Promise<void> {
    try {
      const stream = await this.proctoringService.initializeCamera();
      const videoElement = document.querySelector('.webcam-feed') as HTMLVideoElement;
      if (videoElement) {
        videoElement.srcObject = stream;
      }
      
      this.isProctoringActive = true;
      this.proctoringService.startMonitoring(this.session!.id);
      
      // Listen for violations
      this.proctoringService.violations$.subscribe(violations => {
        this.violations = violations.slice(-3); // Show last 3 violations
      });
      
    } catch (error) {
      console.error('Proctoring initialization failed:', error);
      this.proctoringStatus = {
        type: 'error',
        icon: 'error',
        message: 'Camera access required'
      };
    }
  }

  formatTime(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  }

  previousQuestion(): void {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
      this.loadCurrentQuestion();
    }
  }

  nextQuestion(): void {
    if (this.currentQuestionIndex < this.questions.length - 1) {
      this.currentQuestionIndex++;
      this.loadCurrentQuestion();
    }
  }

  goToQuestion(index: number): void {
    this.currentQuestionIndex = index;
    this.loadCurrentQuestion();
  }

  private loadCurrentQuestion(): void {
    this.currentQuestion = this.questions[this.currentQuestionIndex];
    const savedAnswer = this.answers.get(this.currentQuestion.id);
    this.answerForm.patchValue({ answer: savedAnswer || '' });
  }

  saveAnswer(): void {
    if (!this.currentQuestion || !this.session) return;

    const answer = this.answerForm.get('answer')?.value;
    this.answers.set(this.currentQuestion.id, answer);
    
    // Auto-save indication
    console.log('Answer saved for question', this.currentQuestion.id, ':', answer);
  }

  isQuestionAnswered(index: number): boolean {
    const question = this.questions[index];
    return this.answers.has(question.id) && this.answers.get(question.id) !== '';
  }

  getAnswerPlaceholder(): string {
    if (this.currentQuestion?.type === 'ESSAY') {
      return 'Write your detailed answer here...';
    }
    return 'Enter your answer here...';
  }

  saveAndExit(): void {
    // Save current answer and exit
    this.saveAnswer();
    this.router.navigate(['/student']);
  }

  submitExam(): void {
    if (!this.session || this.isSubmitting) return;

    this.isSubmitting = true;
    
    // Save current answer first
    this.saveAnswer();
    
    // Calculate score
    let score = 0;
    let totalPoints = 0;
    
    this.questions.forEach(question => {
      totalPoints += question.points;
      const studentAnswer = this.answers.get(question.id);
      if (studentAnswer && studentAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim()) {
        score += question.points;
      }
    });
    
    const percentage = (score / totalPoints) * 100;
    
    // Mock submission
    setTimeout(() => {
      this.stopTimer();
      this.proctoringService.stopMonitoring();
      
      // Navigate to results with mock data
      this.router.navigate(['/student/results', this.session!.id], {
        state: { score, percentage, totalPoints }
      });
    }, 1000);
  }
}