import { Routes } from '@angular/router';
import { authGuard } from '../../guards/auth.guard';

export const examRoutes: Routes = [
  {
    path: ':id',
    canActivate: [authGuard],
    loadComponent: () => import('./exam-interface.component').then(m => m.ExamInterfaceComponent)
  }
];