import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UserRole } from '../../models/user.model';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  template: `
    <div class="auth-container fade-in">
      <div class="auth-card card scale-in">
        <div class="auth-header">
          <h1>Create Account</h1>
          <p>Join ExamPortal today</p>
        </div>
        
        <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="auth-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">First Name</label>
              <input 
                type="text" 
                formControlName="firstName" 
                class="form-input"
                [class.error]="registerForm.get('firstName')?.invalid && registerForm.get('firstName')?.touched"
                placeholder="First name">
              <div *ngIf="registerForm.get('firstName')?.invalid && registerForm.get('firstName')?.touched" 
                   class="form-error">
                First name is required
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Last Name</label>
              <input 
                type="text" 
                formControlName="lastName" 
                class="form-input"
                [class.error]="registerForm.get('lastName')?.invalid && registerForm.get('lastName')?.touched"
                placeholder="Last name">
              <div *ngIf="registerForm.get('lastName')?.invalid && registerForm.get('lastName')?.touched" 
                   class="form-error">
                Last name is required
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Username</label>
            <input 
              type="text" 
              formControlName="username" 
              class="form-input"
              [class.error]="registerForm.get('username')?.invalid && registerForm.get('username')?.touched"
              placeholder="Choose a username">
            <div *ngIf="registerForm.get('username')?.invalid && registerForm.get('username')?.touched" 
                 class="form-error">
              Username is required (min 3 characters)
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Email</label>
            <input 
              type="email" 
              formControlName="email" 
              class="form-input"
              [class.error]="registerForm.get('email')?.invalid && registerForm.get('email')?.touched"
              placeholder="Enter your email">
            <div *ngIf="registerForm.get('email')?.invalid && registerForm.get('email')?.touched" 
                 class="form-error">
              Valid email is required
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <input 
              type="password" 
              formControlName="password" 
              class="form-input"
              [class.error]="registerForm.get('password')?.invalid && registerForm.get('password')?.touched"
              placeholder="Create a password">
            <div *ngIf="registerForm.get('password')?.invalid && registerForm.get('password')?.touched" 
                 class="form-error">
              Password is required (min 6 characters)
            </div>
          </div>



          <div *ngIf="errorMessage" class="error-message">
            {{ errorMessage }}
          </div>

          <div *ngIf="successMessage" class="success-message">
            {{ successMessage }}
          </div>

          <button 
            type="submit" 
            class="btn btn-primary btn-lg auth-submit"
            [disabled]="registerForm.invalid || isLoading">
            <span *ngIf="isLoading" class="spinner"></span>
            {{ isLoading ? 'Creating Account...' : 'Create Account' }}
          </button>
        </form>

        <div class="auth-footer">
          <p>Already have an account? <a routerLink="/auth/login">Sign in</a></p>
          <p class="student-note">Note: Public registration is for students only</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
      padding: var(--spacing-md);
    }

    .auth-card {
      width: 100%;
      max-width: 500px;
      padding: var(--spacing-2xl);
      background: var(--bg-card);
      border: none;
    }

    .auth-header {
      text-align: center;
      margin-bottom: var(--spacing-2xl);
    }

    .auth-header h1 {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: var(--spacing-sm);
    }

    .auth-header p {
      color: var(--text-secondary);
      font-size: 0.875rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--spacing-md);
    }

    .auth-form {
      margin-bottom: var(--spacing-xl);
    }

    .auth-submit {
      width: 100%;
      margin-top: var(--spacing-lg);
    }

    .error-message {
      background: rgb(239 68 68 / 0.1);
      color: var(--error-color);
      padding: var(--spacing-sm) var(--spacing-md);
      border-radius: var(--radius-md);
      margin-bottom: var(--spacing-lg);
      font-size: 0.875rem;
    }

    .success-message {
      background: rgb(34 197 94 / 0.1);
      color: var(--success-color);
      padding: var(--spacing-sm) var(--spacing-md);
      border-radius: var(--radius-md);
      margin-bottom: var(--spacing-lg);
      font-size: 0.875rem;
    }

    .auth-footer {
      text-align: center;
      padding-top: var(--spacing-lg);
      border-top: 1px solid var(--border-color);
    }

    .auth-footer a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
    }

    .auth-footer a:hover {
      text-decoration: underline;
    }

    .form-input.error {
      border-color: var(--error-color);
    }

    select.form-input {
      cursor: pointer;
    }

    .student-note {
      margin-top: var(--spacing-md);
      padding: var(--spacing-sm);
      background: var(--bg-tertiary);
      border-radius: var(--radius-sm);
      font-size: 0.75rem;
      color: var(--text-secondary);
      text-align: center;
    }

    @media (max-width: 480px) {
      .auth-card {
        padding: var(--spacing-xl);
      }
      
      .form-row {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class RegisterComponent {
  registerForm: FormGroup;
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';
      this.successMessage = '';

      const formData = { ...this.registerForm.value, role: UserRole.STUDENT };
      this.authService.register(formData).subscribe({
        next: (response) => {
          this.isLoading = false;
          this.successMessage = 'Account created successfully! Please sign in.';
          setTimeout(() => {
            this.router.navigate(['/auth/login']);
          }, 2000);
        },
        error: (error) => {
          this.isLoading = false;
          this.errorMessage = error.error?.message || 'Registration failed. Please try again.';
        }
      });
    }
  }
}