import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface StudentProgress {
  studentId: number;
  studentName: string;
  email: string;
  totalExams: number;
  completedExams: number;
  averageScore: number;
  highestScore: number;
  lowestScore: number;
  totalTimeSpent: number; // in minutes
  lastExamDate: Date | null;
  examResults: ExamResult[];
}

export interface ExamResult {
  examId: number;
  examTitle: string;
  score: number;
  totalMarks: number;
  percentage: number;
  timeSpent: number; // in minutes
  completedAt: Date;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'TERMINATED';
  violations: number;
}

@Injectable({
  providedIn: 'root'
})
export class StudentProgressService {

  constructor() { }

  getAllStudentsProgress(): Observable<StudentProgress[]> {
    // Mock data for student progress
    const mockProgress: StudentProgress[] = [
      {
        studentId: 1,
        studentName: 'Alice Johnson',
        email: 'alice@examportal.com',
        totalExams: 8,
        completedExams: 6,
        averageScore: 87.5,
        highestScore: 95,
        lowestScore: 72,
        totalTimeSpent: 420,
        lastExamDate: new Date('2024-01-20'),
        examResults: [
          {
            examId: 1,
            examTitle: 'Mathematics Final',
            score: 85,
            totalMarks: 100,
            percentage: 85,
            timeSpent: 110,
            completedAt: new Date('2024-01-20'),
            status: 'COMPLETED',
            violations: 0
          },
          {
            examId: 2,
            examTitle: 'Physics Quiz',
            score: 42,
            totalMarks: 50,
            percentage: 84,
            timeSpent: 40,
            completedAt: new Date('2024-01-18'),
            status: 'COMPLETED',
            violations: 1
          }
        ]
      },
      {
        studentId: 2,
        studentName: 'Bob Smith',
        email: 'bob@examportal.com',
        totalExams: 8,
        completedExams: 7,
        averageScore: 92.3,
        highestScore: 98,
        lowestScore: 85,
        totalTimeSpent: 380,
        lastExamDate: new Date('2024-01-22'),
        examResults: [
          {
            examId: 1,
            examTitle: 'Mathematics Final',
            score: 92,
            totalMarks: 100,
            percentage: 92,
            timeSpent: 105,
            completedAt: new Date('2024-01-22'),
            status: 'COMPLETED',
            violations: 0
          },
          {
            examId: 3,
            examTitle: 'Chemistry Test',
            score: 68,
            totalMarks: 75,
            percentage: 90.7,
            timeSpent: 55,
            completedAt: new Date('2024-01-19'),
            status: 'COMPLETED',
            violations: 0
          }
        ]
      },
      {
        studentId: 3,
        studentName: 'Carol Davis',
        email: 'carol@examportal.com',
        totalExams: 8,
        completedExams: 5,
        averageScore: 78.2,
        highestScore: 88,
        lowestScore: 65,
        totalTimeSpent: 290,
        lastExamDate: new Date('2024-01-15'),
        examResults: [
          {
            examId: 2,
            examTitle: 'Physics Quiz',
            score: 38,
            totalMarks: 50,
            percentage: 76,
            timeSpent: 42,
            completedAt: new Date('2024-01-15'),
            status: 'COMPLETED',
            violations: 2
          }
        ]
      }
    ];

    return of(mockProgress);
  }

  getStudentProgress(studentId: number): Observable<StudentProgress | null> {
    return new Observable(observer => {
      this.getAllStudentsProgress().subscribe(students => {
        const student = students.find(s => s.studentId === studentId);
        observer.next(student || null);
        observer.complete();
      });
    });
  }

  getProgressSummary(): Observable<{
    totalStudents: number;
    averageCompletion: number;
    averageScore: number;
    totalViolations: number;
  }> {
    return new Observable(observer => {
      this.getAllStudentsProgress().subscribe(students => {
        const totalStudents = students.length;
        const averageCompletion = students.reduce((sum, s) => sum + (s.completedExams / s.totalExams * 100), 0) / totalStudents;
        const averageScore = students.reduce((sum, s) => sum + s.averageScore, 0) / totalStudents;
        const totalViolations = students.reduce((sum, s) => 
          sum + s.examResults.reduce((vSum, r) => vSum + r.violations, 0), 0);

        observer.next({
          totalStudents,
          averageCompletion: Math.round(averageCompletion * 10) / 10,
          averageScore: Math.round(averageScore * 10) / 10,
          totalViolations
        });
        observer.complete();
      });
    });
  }
}