import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  Exam, 
  ExamRequest, 
  Question, 
  QuestionRequest, 
  ExamSession, 
  StudentAnswer, 
  AnswerSubmissionRequest 
} from '../models/exam.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ExamService {
  private readonly API_URL = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // Student Exam Operations
  getStudentExams(): Observable<Exam[]> {
    return this.http.get<Exam[]>(`${this.API_URL}/student/exams`);
  }

  getExamById(id: number): Observable<Exam> {
    return this.http.get<Exam>(`${this.API_URL}/student/exams/${id}`);
  }

  startExam(examId: number): Observable<ExamSession> {
    return this.http.post<ExamSession>(`${this.API_URL}/student/exams/${examId}/start`, {});
  }

  submitAnswer(sessionId: number, answer: AnswerSubmissionRequest): Observable<StudentAnswer> {
    return this.http.post<StudentAnswer>(`${this.API_URL}/student/sessions/${sessionId}/submit-answer`, answer);
  }

  submitExam(sessionId: number): Observable<ExamSession> {
    return this.http.post<ExamSession>(`${this.API_URL}/student/sessions/${sessionId}/submit`, {});
  }

  getExamSession(sessionId: number): Observable<ExamSession> {
    return this.http.get<ExamSession>(`${this.API_URL}/student/sessions/${sessionId}`);
  }

  getStudentSessions(): Observable<ExamSession[]> {
    return this.http.get<ExamSession[]>(`${this.API_URL}/student/sessions`);
  }

  getStudentPerformance(): Observable<any> {
    return this.http.get(`${this.API_URL}/student/performance`);
  }

  // Instructor Exam Operations
  getInstructorExams(): Observable<Exam[]> {
    return this.http.get<Exam[]>(`${this.API_URL}/instructor/exams`);
  }

  createExam(exam: ExamRequest): Observable<Exam> {
    return this.http.post<Exam>(`${this.API_URL}/instructor/exams`, exam);
  }

  updateExam(id: number, exam: ExamRequest): Observable<Exam> {
    return this.http.put<Exam>(`${this.API_URL}/instructor/exams/${id}`, exam);
  }

  deleteExam(id: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/instructor/exams/${id}`);
  }

  assignStudentsToExam(examId: number, studentIds: number[]): Observable<Exam> {
    return this.http.post<Exam>(`${this.API_URL}/instructor/exams/${examId}/assign-students`, studentIds);
  }

  getExamAnalytics(examId: number): Observable<any> {
    return this.http.get(`${this.API_URL}/instructor/exams/${examId}/analytics`);
  }

  getExamResultsCSV(examId: number): Observable<string> {
    return this.http.get(`${this.API_URL}/instructor/exams/${examId}/results/csv`, { responseType: 'text' });
  }

  // Question Management
  getAllQuestions(): Observable<Question[]> {
    return this.http.get<Question[]>(`${this.API_URL}/instructor/questions`);
  }

  getQuestionById(id: number): Observable<Question> {
    return this.http.get<Question>(`${this.API_URL}/instructor/questions/${id}`);
  }

  createQuestion(question: QuestionRequest): Observable<Question> {
    return this.http.post<Question>(`${this.API_URL}/instructor/questions`, question);
  }

  updateQuestion(id: number, question: QuestionRequest): Observable<Question> {
    return this.http.put<Question>(`${this.API_URL}/instructor/questions/${id}`, question);
  }

  deleteQuestion(id: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/instructor/questions/${id}`);
  }

  getQuestionCategories(): Observable<string[]> {
    return this.http.get<string[]>(`${this.API_URL}/instructor/questions/categories`);
  }

  getQuestionsByCategory(category: string): Observable<Question[]> {
    return this.http.get<Question[]>(`${this.API_URL}/instructor/questions/category/${category}`);
  }

  getAllStudents(): Observable<any[]> {
    return this.http.get<any[]>(`${this.API_URL}/instructor/students`);
  }
}