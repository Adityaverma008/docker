import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { 
  ProctoringLog, 
  ProctoringEventRequest, 
  AIAnalysisResult,
  EventType,
  SeverityLevel 
} from '../models/proctoring.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProctoringService {
  private readonly API_URL = environment.apiUrl + '/proctoring';
  private mediaStream: MediaStream | null = null;
  private isMonitoring = false;
  private monitoringInterval: any;
  
  private violationsSubject = new BehaviorSubject<ProctoringLog[]>([]);
  public violations$ = this.violationsSubject.asObservable();

  constructor(private http: HttpClient) {}

  async initializeCamera(): Promise<MediaStream> {
    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false
      });
      return this.mediaStream;
    } catch (error) {
      throw new Error('Camera access denied or not available');
    }
  }

  startMonitoring(sessionId: number): void {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    
    // Capture snapshots every 30 seconds
    this.monitoringInterval = setInterval(() => {
      this.captureAndAnalyze(sessionId);
    }, 30000);

    // Monitor tab visibility
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.logEvent(sessionId, EventType.TAB_SWITCH, SeverityLevel.MEDIUM, 'User switched tabs or minimized window');
      }
    });

    // Monitor window focus
    window.addEventListener('blur', () => {
      this.logEvent(sessionId, EventType.WINDOW_FOCUS_LOST, SeverityLevel.MEDIUM, 'Window lost focus');
    });
  }

  stopMonitoring(): void {
    this.isMonitoring = false;
    
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
  }

  private async captureAndAnalyze(sessionId: number): Promise<void> {
    if (!this.mediaStream) return;

    try {
      const canvas = document.createElement('canvas');
      const video = document.createElement('video');
      video.srcObject = this.mediaStream;
      
      await new Promise(resolve => {
        video.onloadedmetadata = resolve;
      });
      
      video.play();
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0);
      
      const imageData = canvas.toDataURL('image/jpeg', 0.8);
      
      // Send to AI analysis
      this.analyzeImage(imageData).subscribe(result => {
        this.handleAnalysisResult(sessionId, result, imageData);
      });
      
    } catch (error) {
      console.error('Error capturing webcam snapshot:', error);
    }
  }

  private handleAnalysisResult(sessionId: number, result: AIAnalysisResult, imageData: string): void {
    if (!result.faceDetected) {
      this.logEventWithImage(sessionId, EventType.FACE_NOT_DETECTED, SeverityLevel.HIGH, 
        'No face detected in webcam feed', imageData);
    }
    
    if (result.multipleFaces) {
      this.logEventWithImage(sessionId, EventType.MULTIPLE_FACES, SeverityLevel.CRITICAL, 
        'Multiple faces detected - possible cheating', imageData);
    }
    
    if (result.suspiciousActivity) {
      this.logEventWithImage(sessionId, EventType.SUSPICIOUS_MOVEMENT, SeverityLevel.HIGH, 
        'Suspicious activity detected', imageData);
    }
  }

  logEvent(sessionId: number, eventType: EventType, severity: SeverityLevel, description: string): Observable<ProctoringLog> {
    const request: ProctoringEventRequest = {
      sessionId,
      eventType,
      severity,
      description
    };
    
    return this.http.post<ProctoringLog>(`${this.API_URL}/events`, request);
  }

  logEventWithImage(sessionId: number, eventType: EventType, severity: SeverityLevel, 
                   description: string, imageData: string): Observable<ProctoringLog> {
    const request: ProctoringEventRequest = {
      sessionId,
      eventType,
      severity,
      description,
      imageData
    };
    
    return this.http.post<ProctoringLog>(`${this.API_URL}/events`, request);
  }

  analyzeImage(imageData: string): Observable<AIAnalysisResult> {
    return this.http.get<AIAnalysisResult>(`${this.API_URL}/ai-analysis`, {
      params: { imageData }
    });
  }

  getSessionLogs(sessionId: number): Observable<ProctoringLog[]> {
    return this.http.get<ProctoringLog[]>(`${this.API_URL}/sessions/${sessionId}/logs`);
  }

  getSessionViolations(sessionId: number): Observable<ProctoringLog[]> {
    return this.http.get<ProctoringLog[]>(`${this.API_URL}/sessions/${sessionId}/violations`);
  }

  uploadWebcamSnapshot(sessionId: number, file: File, eventType: EventType, 
                      severity: SeverityLevel, description?: string): Observable<ProctoringLog> {
    const formData = new FormData();
    formData.append('sessionId', sessionId.toString());
    formData.append('file', file);
    formData.append('eventType', eventType);
    formData.append('severity', severity);
    if (description) {
      formData.append('description', description);
    }
    
    return this.http.post<ProctoringLog>(`${this.API_URL}/webcam-snapshot`, formData);
  }

  getMediaStream(): MediaStream | null {
    return this.mediaStream;
  }

  isCurrentlyMonitoring(): boolean {
    return this.isMonitoring;
  }
}