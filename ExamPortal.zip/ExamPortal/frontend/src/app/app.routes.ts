import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';
import { UserRole } from './models/user.model';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'auth',
    loadChildren: () => import('./components/auth/auth.routes').then(m => m.authRoutes)
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard],
    data: { roles: [UserRole.ADMIN] },
    loadChildren: () => import('./components/dashboard/admin/admin.routes').then(m => m.adminRoutes)
  },
  {
    path: 'instructor',
    canActivate: [authGuard, roleGuard],
    data: { roles: [UserRole.ADMIN, UserRole.INSTRUCTOR] },
    loadChildren: () => import('./components/dashboard/instructor/instructor.routes').then(m => m.instructorRoutes)
  },
  {
    path: 'student',
    canActivate: [authGuard, roleGuard],
    data: { roles: [UserRole.STUDENT] },
    loadChildren: () => import('./components/dashboard/student/student.routes').then(m => m.studentRoutes)
  },
  {
    path: 'exam',
    canActivate: [authGuard],
    loadChildren: () => import('./components/exam/exam.routes').then(m => m.examRoutes)
  },
  {
    path: 'profile',
    canActivate: [authGuard],
    loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent)
  },
  {
    path: 'student-progress',
    canActivate: [authGuard, roleGuard],
    data: { roles: [UserRole.ADMIN, UserRole.INSTRUCTOR] },
    loadComponent: () => import('./components/student-progress/student-progress.component').then(m => m.StudentProgressComponent)
  },
  {
    path: '**',
    redirectTo: '/dashboard'
  }
];