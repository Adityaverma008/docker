export interface ProctoringLog {
  id: number;
  examSession: any;
  eventType: EventType;
  severity: SeverityLevel;
  description: string;
  imageUrl?: string;
  metadata?: string;
  timestamp: Date;
}

export enum EventType {
  FACE_NOT_DETECTED = 'FACE_NOT_DETECTED',
  MULTIPLE_FACES = 'MULTIPLE_FACES',
  GAZE_AWAY = 'GAZE_AWAY',
  TAB_SWITCH = 'TAB_SWITCH',
  WINDOW_FOCUS_LOST = 'WINDOW_FOCUS_LOST',
  SUSPICIOUS_MOVEMENT = 'SUSPICIOUS_MOVEMENT',
  AUDIO_DETECTED = 'AUDIO_DETECTED',
  SCREEN_SHARE_DETECTED = 'SCREEN_SHARE_DETECTED',
  EXAM_START = 'EXAM_START',
  EXAM_END = 'EXAM_END',
  VIOLATION = 'VIOLATION'
}

export enum SeverityLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export interface ProctoringEventRequest {
  sessionId: number;
  eventType: EventType;
  severity: SeverityLevel;
  description: string;
  imageData?: string;
  metadata?: string;
}

export interface AIAnalysisResult {
  faceDetected: boolean;
  multipleFaces: boolean;
  gazeDirection: string;
  suspiciousActivity: boolean;
  confidence: number;
}