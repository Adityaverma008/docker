export interface Exam {
  id: number;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  startTime: Date;
  endTime: Date;
  randomizeQuestions: boolean;
  active: boolean;
  instructor: any;
  questions: Question[];
  assignedStudents: any[];
  examSessions: any[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Question {
  id: number;
  content: string;
  type: QuestionType;
  difficulty: DifficultyLevel;
  category: string;
  tags: string;
  points: number;
  options: string[];
  correctAnswer: string;
  createdAt: Date;
  updatedAt: Date;
}

export enum QuestionType {
  MCQ = 'MCQ',
  SHORT_ANSWER = 'SHORT_ANSWER',
  ESSAY = 'ESSAY',
  TRUE_FALSE = 'TRUE_FALSE'
}

export enum DifficultyLevel {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export interface ExamSession {
  id: number;
  exam: Exam;
  student: any;
  startTime: Date;
  endTime: Date | null;
  submittedAt: Date | null;
  status: SessionStatus;
  score: number | null;
  percentage: number | null;
  ipAddress: string;
  userAgent: string;
  createdAt: Date;
  updatedAt: Date;
}

export enum SessionStatus {
  NOT_STARTED = 'NOT_STARTED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  TERMINATED = 'TERMINATED',
  TIMEOUT = 'TIMEOUT'
}

export interface StudentAnswer {
  id: number;
  examSession: ExamSession;
  question: Question;
  answer: string;
  isCorrect: boolean;
  pointsEarned: number;
  answeredAt: Date;
}

export interface ExamRequest {
  title: string;
  description: string;
  duration: number;
  startTime: Date;
  endTime: Date;
  randomizeQuestions: boolean;
  questionIds: number[];
  studentIds: number[];
}

export interface QuestionRequest {
  content: string;
  type: QuestionType;
  difficulty: DifficultyLevel;
  category: string;
  tags: string;
  points: number;
  options: string[];
  correctAnswer: string;
}

export interface AnswerSubmissionRequest {
  questionId: number;
  answer: string;
}