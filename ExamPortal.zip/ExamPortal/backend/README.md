# Online Exam & Proctoring System Backend

A secure and scalable backend for an Online Exam & Proctoring System built with Spring Boot and MySQL.

## Features

### 🔐 User Management
- **Multi-role system**: Admin, Instructor, Student
- **Secure authentication**: JWT-based with BCrypt password encryption
- **Role-based access control**: Endpoint protection based on user roles
- **User registration and profile management**

### 📝 Exam Management
- **CRUD operations** for exams
- **Question bank management** with categories and difficulty levels
- **Student assignment** to exams
- **Time limits and randomization** support
- **Multiple question types**: MCQ, Short Answer, Essay, True/False

### 🎯 Question Bank
- **Comprehensive question management**
- **Tagging and categorization**
- **Difficulty levels**: Easy, Medium, Hard
- **Support for multiple question types**

### 👁️ Proctoring Features
- **Webcam snapshot upload** endpoints
- **AI service integration** ready for face detection and gaze tracking
- **Suspicious activity logging** with severity levels
- **Real-time monitoring** capabilities

### 📊 Exam Session Tracking
- **Session lifecycle management**: Start, Progress, Complete, Terminate
- **Real-time status updates**
- **Auto-submit on timeout** or violation detection
- **IP and browser tracking**

### 📈 Results & Analytics
- **Score calculation and storage**
- **Performance reports** generation
- **CSV export** functionality
- **Student performance analytics**

### 🛡️ Security & Audit
- **Comprehensive audit logging**
- **IP tracking and user agent logging**
- **Security violation detection**
- **Rate limiting ready** infrastructure

## Technology Stack

- **Framework**: Spring Boot 3.2.0
- **Database**: MySQL 8.0
- **Security**: Spring Security with JWT
- **ORM**: JPA/Hibernate
- **Build Tool**: Maven
- **Java Version**: 17

## Prerequisites

- Java 17 or higher
- MySQL 8.0 or higher
- Maven 3.6 or higher

## Setup Instructions

### 1. Database Setup
```sql
CREATE DATABASE exam_portal_db;
CREATE USER 'exam_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON exam_portal_db.* TO 'exam_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Application Configuration
Update `src/main/resources/application.yml`:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/exam_portal_db
    username: your_username
    password: your_password
```

### 3. Build and Run
```bash
# Navigate to backend directory
cd backend

# Build the application
mvn clean install

# Run the application
mvn spring-boot:run
```

The application will start on `http://localhost:8080/api`

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout

### Admin Endpoints
- `GET /api/admin/users` - Get all users
- `GET /api/admin/users/role/{role}` - Get users by role
- `PUT /api/admin/users/{id}` - Update user
- `DELETE /api/admin/users/{id}` - Delete user
- `GET /api/admin/audit-logs` - Get audit logs

### Instructor Endpoints
- `POST /api/instructor/questions` - Create question
- `GET /api/instructor/questions` - Get all questions
- `PUT /api/instructor/questions/{id}` - Update question
- `DELETE /api/instructor/questions/{id}` - Delete question
- `POST /api/instructor/exams` - Create exam
- `GET /api/instructor/exams` - Get instructor's exams
- `PUT /api/instructor/exams/{id}` - Update exam
- `GET /api/instructor/exams/{id}/analytics` - Get exam analytics

### Student Endpoints
- `GET /api/student/exams` - Get assigned exams
- `POST /api/student/exams/{examId}/start` - Start exam session
- `POST /api/student/sessions/{sessionId}/submit-answer` - Submit answer
- `POST /api/student/sessions/{sessionId}/submit` - Submit exam
- `GET /api/student/performance` - Get performance report

### Proctoring Endpoints
- `POST /api/proctoring/events` - Log proctoring event
- `POST /api/proctoring/webcam-snapshot` - Upload webcam snapshot
- `GET /api/proctoring/sessions/{sessionId}/logs` - Get session logs
- `GET /api/proctoring/sessions/{sessionId}/violations` - Get violations

## Database Schema

The application uses the following main entities:
- **User**: User management with roles
- **Question**: Question bank with categories and types
- **Exam**: Exam configuration and management
- **ExamSession**: Individual exam attempts
- **StudentAnswer**: Student responses to questions
- **ProctoringLog**: Monitoring and violation logs
- **AuditLog**: System audit trail

## Security Features

- **JWT Authentication**: Stateless authentication with configurable expiration
- **Password Encryption**: BCrypt hashing for secure password storage
- **Role-based Access**: Method-level security with role checking
- **CORS Configuration**: Configurable cross-origin resource sharing
- **Audit Logging**: Comprehensive activity tracking
- **IP Tracking**: Request origin monitoring

## Proctoring Integration

The system is designed to integrate with AI services for:
- **Face Detection**: Verify student identity
- **Gaze Tracking**: Monitor attention and focus
- **Multiple Face Detection**: Detect unauthorized assistance
- **Suspicious Movement**: Identify unusual behavior
- **Audio Detection**: Monitor for unauthorized communication

## Future Enhancements

- **Real-time WebSocket** communication for live monitoring
- **Advanced AI integration** for automated proctoring
- **Mobile app support** with responsive APIs
- **Advanced analytics** and reporting
- **Integration with LMS** platforms
- **Video recording** and playback capabilities

## Development

### Running Tests
```bash
mvn test
```

### Building for Production
```bash
mvn clean package -Pprod
```

### Docker Support
```dockerfile
# Dockerfile example
FROM openjdk:17-jdk-slim
COPY target/exam-portal-backend-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License.