package com.examportal.service;

import com.examportal.entity.Exam;
import com.examportal.entity.ExamSession;
import com.examportal.entity.StudentAnswer;
import com.examportal.repository.ExamRepository;
import com.examportal.repository.ExamSessionRepository;
import com.examportal.repository.StudentAnswerRepository;
import com.opencsv.CSVWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.StringWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReportService {
    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private ExamSessionRepository examSessionRepository;

    @Autowired
    private StudentAnswerRepository studentAnswerRepository;

    public String generateExamResultsCSV(Long examId) {
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() -> new RuntimeException("Exam not found: " + examId));

        List<ExamSession> sessions = examSessionRepository.findByExam(exam);

        StringWriter stringWriter = new StringWriter();
        CSVWriter csvWriter = new CSVWriter(stringWriter);

        // Write header
        String[] header = {"Student Name", "Username", "Score", "Percentage", "Status", "Start Time", "End Time", "Duration"};
        csvWriter.writeNext(header);

        // Write data
        for (ExamSession session : sessions) {
            String[] row = {
                session.getStudent().getFirstName() + " " + session.getStudent().getLastName(),
                session.getStudent().getUsername(),
                session.getScore() != null ? session.getScore().toString() : "0",
                session.getPercentage() != null ? String.format("%.2f", session.getPercentage()) : "0.00",
                session.getStatus().toString(),
                session.getStartTime() != null ? session.getStartTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : "",
                session.getEndTime() != null ? session.getEndTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : "",
                calculateDuration(session)
            };
            csvWriter.writeNext(row);
        }

        try {
            csvWriter.close();
        } catch (Exception e) {
            throw new RuntimeException("Error generating CSV: " + e.getMessage());
        }

        return stringWriter.toString();
    }

    public Map<String, Object> generateExamAnalytics(Long examId) {
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() -> new RuntimeException("Exam not found: " + examId));

        List<ExamSession> sessions = examSessionRepository.findByExam(exam);
        List<ExamSession> completedSessions = sessions.stream()
                .filter(s -> s.getStatus() == ExamSession.SessionStatus.COMPLETED)
                .collect(Collectors.toList());

        double averageScore = completedSessions.stream()
                .mapToInt(s -> s.getScore() != null ? s.getScore() : 0)
                .average()
                .orElse(0.0);

        double averagePercentage = completedSessions.stream()
                .mapToDouble(s -> s.getPercentage() != null ? s.getPercentage() : 0.0)
                .average()
                .orElse(0.0);

        long totalAttempts = sessions.size();
        long completedAttempts = completedSessions.size();
        long terminatedAttempts = sessions.stream()
                .filter(s -> s.getStatus() == ExamSession.SessionStatus.TERMINATED)
                .count();

        return Map.of(
                "examTitle", exam.getTitle(),
                "totalAttempts", totalAttempts,
                "completedAttempts", completedAttempts,
                "terminatedAttempts", terminatedAttempts,
                "averageScore", averageScore,
                "averagePercentage", averagePercentage,
                "totalQuestions", exam.getQuestions().size(),
                "totalMarks", exam.getTotalMarks() != null ? exam.getTotalMarks() : 0
        );
    }

    public Map<String, Object> generateStudentPerformanceReport(Long studentId) {
        List<ExamSession> sessions = examSessionRepository.findByStudentIdAndStatusIn(
                studentId, List.of(ExamSession.SessionStatus.COMPLETED));

        double averagePercentage = sessions.stream()
                .mapToDouble(s -> s.getPercentage() != null ? s.getPercentage() : 0.0)
                .average()
                .orElse(0.0);

        int totalExamsAttempted = sessions.size();
        long passedExams = sessions.stream()
                .filter(s -> s.getPercentage() != null && s.getPercentage() >= 60.0)
                .count();

        return Map.of(
                "totalExamsAttempted", totalExamsAttempted,
                "passedExams", passedExams,
                "averagePercentage", averagePercentage,
                "sessions", sessions.stream().map(this::mapSessionToReport).collect(Collectors.toList())
        );
    }

    private String calculateDuration(ExamSession session) {
        if (session.getStartTime() != null && session.getEndTime() != null) {
            long minutes = java.time.Duration.between(session.getStartTime(), session.getEndTime()).toMinutes();
            return minutes + " minutes";
        }
        return "N/A";
    }

    private Map<String, Object> mapSessionToReport(ExamSession session) {
        return Map.of(
                "examTitle", session.getExam().getTitle(),
                "score", session.getScore() != null ? session.getScore() : 0,
                "percentage", session.getPercentage() != null ? session.getPercentage() : 0.0,
                "status", session.getStatus().toString(),
                "submittedAt", session.getSubmittedAt() != null ? 
                        session.getSubmittedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : ""
        );
    }
}