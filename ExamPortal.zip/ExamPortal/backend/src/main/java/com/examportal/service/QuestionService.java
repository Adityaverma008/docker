package com.examportal.service;

import com.examportal.dto.QuestionRequest;
import com.examportal.entity.Question;
import com.examportal.exception.ResourceNotFoundException;
import com.examportal.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {
    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private AuditService auditService;

    public Question createQuestion(QuestionRequest request) {
        Question question = new Question();
        question.setContent(request.getContent());
        question.setType(request.getType());
        question.setDifficulty(request.getDifficulty());
        question.setCategory(request.getCategory());
        question.setTags(request.getTags());
        question.setPoints(request.getPoints());
        question.setOptions(request.getOptions());
        question.setCorrectAnswer(request.getCorrectAnswer());
        
        Question savedQuestion = questionRepository.save(question);
        auditService.logAction("Question created: " + savedQuestion.getId(), "CREATE");
        return savedQuestion;
    }

    public Question getQuestionById(Long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id: " + id));
    }

    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }

    public List<Question> getQuestionsByCategory(String category) {
        return questionRepository.findByCategory(category);
    }

    public List<Question> getQuestionsByType(Question.QuestionType type) {
        return questionRepository.findByType(type);
    }

    public List<Question> getQuestionsByDifficulty(Question.DifficultyLevel difficulty) {
        return questionRepository.findByDifficulty(difficulty);
    }

    public List<String> getAllCategories() {
        return questionRepository.findAllCategories();
    }

    public Question updateQuestion(Long id, QuestionRequest request) {
        Question question = getQuestionById(id);
        question.setContent(request.getContent());
        question.setType(request.getType());
        question.setDifficulty(request.getDifficulty());
        question.setCategory(request.getCategory());
        question.setTags(request.getTags());
        question.setPoints(request.getPoints());
        question.setOptions(request.getOptions());
        question.setCorrectAnswer(request.getCorrectAnswer());
        
        Question updatedQuestion = questionRepository.save(question);
        auditService.logAction("Question updated: " + updatedQuestion.getId(), "UPDATE");
        return updatedQuestion;
    }

    public void deleteQuestion(Long id) {
        Question question = getQuestionById(id);
        questionRepository.delete(question);
        auditService.logAction("Question deleted: " + id, "DELETE");
    }
}