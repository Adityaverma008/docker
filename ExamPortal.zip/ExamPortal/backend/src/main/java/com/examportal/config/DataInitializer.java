package com.examportal.config;

import com.examportal.entity.User;
import com.examportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create default admin user if not exists
        if (!userRepository.existsByUsername("Addy")) {
            User admin = new User();
            admin.setUsername("Addy");
            admin.setEmail("aditya@examportal.com");
            admin.setPassword(passwordEncoder.encode("Aditya@1234"));
            admin.setFirstName("Aditya");
            admin.setLastName("Verma");
            admin.setRole(User.Role.ADMIN);
            admin.setEnabled(true);
            
            userRepository.save(admin);
            System.out.println("Default admin user created: Addy");
        }
    }
}