package com.examportal.service;

import com.examportal.dto.ProctoringEventRequest;
import com.examportal.entity.ExamSession;
import com.examportal.entity.ProctoringLog;
import com.examportal.exception.ResourceNotFoundException;
import com.examportal.repository.ExamSessionRepository;
import com.examportal.repository.ProctoringLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class ProctoringService {
    @Autowired
    private ProctoringLogRepository proctoringLogRepository;

    @Autowired
    private ExamSessionRepository examSessionRepository;

    @Autowired
    private AuditService auditService;

    private final String UPLOAD_DIR = "uploads/proctoring/";

    public ProctoringLog logProctoringEvent(ProctoringEventRequest request) {
        ExamSession session = examSessionRepository.findById(request.getSessionId())
                .orElseThrow(() -> new ResourceNotFoundException("Exam session not found: " + request.getSessionId()));

        ProctoringLog log = new ProctoringLog();
        log.setExamSession(session);
        log.setEventType(request.getEventType());
        log.setSeverity(request.getSeverity());
        log.setDescription(request.getDescription());
        log.setMetadata(request.getMetadata());

        // Handle image data if provided
        if (request.getImageData() != null && !request.getImageData().isEmpty()) {
            String imageUrl = saveBase64Image(request.getImageData());
            log.setImageUrl(imageUrl);
        }

        ProctoringLog savedLog = proctoringLogRepository.save(log);

        // Log high severity events in audit
        if (request.getSeverity() == ProctoringLog.SeverityLevel.HIGH || 
            request.getSeverity() == ProctoringLog.SeverityLevel.CRITICAL) {
            auditService.logUserAction(session.getStudent().getId(), session.getStudent().getUsername(),
                    "Proctoring violation: " + request.getEventType(), "VIOLATION");
        }

        // Auto-terminate session for critical violations
        if (request.getSeverity() == ProctoringLog.SeverityLevel.CRITICAL) {
            session.setStatus(ExamSession.SessionStatus.TERMINATED);
            session.setEndTime(LocalDateTime.now());
            examSessionRepository.save(session);
        }

        return savedLog;
    }

    public ProctoringLog uploadWebcamSnapshot(Long sessionId, MultipartFile file, 
                                            ProctoringLog.EventType eventType, 
                                            ProctoringLog.SeverityLevel severity, 
                                            String description) throws IOException {
        ExamSession session = examSessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam session not found: " + sessionId));

        String imageUrl = saveUploadedFile(file);

        ProctoringLog log = new ProctoringLog();
        log.setExamSession(session);
        log.setEventType(eventType);
        log.setSeverity(severity);
        log.setDescription(description);
        log.setImageUrl(imageUrl);

        return proctoringLogRepository.save(log);
    }

    public List<ProctoringLog> getSessionLogs(Long sessionId) {
        ExamSession session = examSessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam session not found: " + sessionId));
        return proctoringLogRepository.findByExamSession(session);
    }

    public List<ProctoringLog> getHighSeverityLogs(Long sessionId) {
        return proctoringLogRepository.findBySessionIdAndSeverityIn(sessionId, 
                List.of(ProctoringLog.SeverityLevel.HIGH, ProctoringLog.SeverityLevel.CRITICAL));
    }

    public List<ProctoringLog> getLogsByEventType(ProctoringLog.EventType eventType) {
        return proctoringLogRepository.findByEventType(eventType);
    }

    private String saveBase64Image(String base64Data) {
        try {
            // Remove data URL prefix if present
            String imageData = base64Data;
            if (base64Data.contains(",")) {
                imageData = base64Data.split(",")[1];
            }

            byte[] imageBytes = Base64.getDecoder().decode(imageData);
            String fileName = UUID.randomUUID().toString() + ".jpg";
            Path uploadPath = Paths.get(UPLOAD_DIR);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            Path filePath = uploadPath.resolve(fileName);
            Files.write(filePath, imageBytes);
            
            return UPLOAD_DIR + fileName;
        } catch (Exception e) {
            throw new RuntimeException("Failed to save image: " + e.getMessage());
        }
    }

    private String saveUploadedFile(MultipartFile file) throws IOException {
        String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
        Path uploadPath = Paths.get(UPLOAD_DIR);
        
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        
        Path filePath = uploadPath.resolve(fileName);
        Files.copy(file.getInputStream(), filePath);
        
        return UPLOAD_DIR + fileName;
    }
}