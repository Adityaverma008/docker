package com.examportal.repository;

import com.examportal.entity.ExamSession;
import com.examportal.entity.User;
import com.examportal.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExamSessionRepository extends JpaRepository<ExamSession, Long> {
    Optional<ExamSession> findByExamAndStudent(Exam exam, User student);
    List<ExamSession> findByStudent(User student);
    List<ExamSession> findByExam(Exam exam);
    List<ExamSession> findByStatus(ExamSession.SessionStatus status);
    
    @Query("SELECT es FROM ExamSession es WHERE es.exam.id = :examId AND es.status = :status")
    List<ExamSession> findByExamIdAndStatus(Long examId, ExamSession.SessionStatus status);
    
    @Query("SELECT es FROM ExamSession es WHERE es.student.id = :studentId AND es.status IN :statuses")
    List<ExamSession> findByStudentIdAndStatusIn(Long studentId, List<ExamSession.SessionStatus> statuses);
}