package com.examportal.service;

import com.examportal.dto.ExamRequest;
import com.examportal.entity.Exam;
import com.examportal.entity.Question;
import com.examportal.entity.User;
import com.examportal.exception.ResourceNotFoundException;
import com.examportal.repository.ExamRepository;
import com.examportal.repository.QuestionRepository;
import com.examportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ExamService {
    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditService auditService;

    public Exam createExam(ExamRequest request, User instructor) {
        Exam exam = new Exam();
        exam.setTitle(request.getTitle());
        exam.setDescription(request.getDescription());
        exam.setDuration(request.getDuration());
        exam.setStartTime(request.getStartTime());
        exam.setEndTime(request.getEndTime());
        exam.setRandomizeQuestions(request.isRandomizeQuestions());
        exam.setInstructor(instructor);

        // Add questions
        if (request.getQuestionIds() != null && !request.getQuestionIds().isEmpty()) {
            Set<Question> questions = new HashSet<>();
            for (Long questionId : request.getQuestionIds()) {
                Question question = questionRepository.findById(questionId)
                        .orElseThrow(() -> new ResourceNotFoundException("Question not found: " + questionId));
                questions.add(question);
            }
            exam.setQuestions(questions);
            
            // Calculate total marks
            int totalMarks = questions.stream().mapToInt(Question::getPoints).sum();
            exam.setTotalMarks(totalMarks);
        }

        // Assign students
        if (request.getStudentIds() != null && !request.getStudentIds().isEmpty()) {
            Set<User> students = new HashSet<>();
            for (Long studentId : request.getStudentIds()) {
                User student = userRepository.findById(studentId)
                        .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));
                students.add(student);
            }
            exam.setAssignedStudents(students);
        }

        Exam savedExam = examRepository.save(exam);
        auditService.logAction("Exam created: " + savedExam.getTitle(), "CREATE");
        return savedExam;
    }

    public Exam getExamById(Long id) {
        return examRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found with id: " + id));
    }

    public List<Exam> getAllExams() {
        return examRepository.findAll();
    }

    public List<Exam> getExamsByInstructor(User instructor) {
        return examRepository.findByInstructor(instructor);
    }

    public List<Exam> getActiveExamsForStudent(Long studentId) {
        return examRepository.findActiveExamsForStudent(studentId);
    }

    public List<Exam> getCurrentlyActiveExams() {
        return examRepository.findCurrentlyActiveExams(LocalDateTime.now());
    }

    public Exam updateExam(Long id, ExamRequest request) {
        Exam exam = getExamById(id);
        exam.setTitle(request.getTitle());
        exam.setDescription(request.getDescription());
        exam.setDuration(request.getDuration());
        exam.setStartTime(request.getStartTime());
        exam.setEndTime(request.getEndTime());
        exam.setRandomizeQuestions(request.isRandomizeQuestions());

        Exam updatedExam = examRepository.save(exam);
        auditService.logAction("Exam updated: " + updatedExam.getTitle(), "UPDATE");
        return updatedExam;
    }

    public void deleteExam(Long id) {
        Exam exam = getExamById(id);
        examRepository.delete(exam);
        auditService.logAction("Exam deleted: " + exam.getTitle(), "DELETE");
    }

    public Exam assignStudentsToExam(Long examId, List<Long> studentIds) {
        Exam exam = getExamById(examId);
        Set<User> students = new HashSet<>();
        
        for (Long studentId : studentIds) {
            User student = userRepository.findById(studentId)
                    .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));
            students.add(student);
        }
        
        exam.setAssignedStudents(students);
        return examRepository.save(exam);
    }
}