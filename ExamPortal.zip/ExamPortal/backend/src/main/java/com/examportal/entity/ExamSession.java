package com.examportal.entity;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "exam_sessions")
@EntityListeners(AuditingEntityListener.class)
public class ExamSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id")
    private Exam exam;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id")
    private User student;

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private LocalDateTime submittedAt;

    @Enumerated(EnumType.STRING)
    private SessionStatus status = SessionStatus.NOT_STARTED;

    private Integer score;
    private Double percentage;
    private String ipAddress;
    private String userAgent;

    @OneToMany(mappedBy = "examSession", cascade = CascadeType.ALL)
    private Set<StudentAnswer> answers = new HashSet<>();

    @OneToMany(mappedBy = "examSession", cascade = CascadeType.ALL)
    private Set<ProctoringLog> proctoringLogs = new HashSet<>();

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;

    public enum SessionStatus {
        NOT_STARTED, IN_PROGRESS, COMPLETED, TERMINATED, TIMEOUT
    }

    // Constructors
    public ExamSession() {}

    public ExamSession(Exam exam, User student) {
        this.exam = exam;
        this.student = student;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Exam getExam() { return exam; }
    public void setExam(Exam exam) { this.exam = exam; }

    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public LocalDateTime getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(LocalDateTime submittedAt) { this.submittedAt = submittedAt; }

    public SessionStatus getStatus() { return status; }
    public void setStatus(SessionStatus status) { this.status = status; }

    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }

    public Double getPercentage() { return percentage; }
    public void setPercentage(Double percentage) { this.percentage = percentage; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public Set<StudentAnswer> getAnswers() { return answers; }
    public void setAnswers(Set<StudentAnswer> answers) { this.answers = answers; }

    public Set<ProctoringLog> getProctoringLogs() { return proctoringLogs; }
    public void setProctoringLogs(Set<ProctoringLog> proctoringLogs) { this.proctoringLogs = proctoringLogs; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}