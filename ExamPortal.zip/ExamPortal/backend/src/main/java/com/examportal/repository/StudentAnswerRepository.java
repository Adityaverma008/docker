package com.examportal.repository;

import com.examportal.entity.StudentAnswer;
import com.examportal.entity.ExamSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentAnswerRepository extends JpaRepository<StudentAnswer, Long> {
    List<StudentAnswer> findByExamSession(ExamSession examSession);
    Optional<StudentAnswer> findByExamSessionAndQuestionId(ExamSession examSession, Long questionId);
    List<StudentAnswer> findByExamSessionAndIsCorrectTrue(ExamSession examSession);
}