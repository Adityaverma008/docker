package com.examportal.util;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class ResponseUtil {
    
    public static Map<String, Object> createSuccessResponse(String message, Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        response.put("data", data);
        response.put("timestamp", LocalDateTime.now());
        return response;
    }
    
    public static Map<String, Object> createSuccessResponse(String message) {
        return createSuccessResponse(message, null);
    }
    
    public static Map<String, Object> createErrorResponse(String message, Object errors) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        response.put("errors", errors);
        response.put("timestamp", LocalDateTime.now());
        return response;
    }
    
    public static Map<String, Object> createErrorResponse(String message) {
        return createErrorResponse(message, null);
    }
}