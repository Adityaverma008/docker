package com.examportal.repository;

import com.examportal.entity.ProctoringLog;
import com.examportal.entity.ExamSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ProctoringLogRepository extends JpaRepository<ProctoringLog, Long> {
    List<ProctoringLog> findByExamSession(ExamSession examSession);
    List<ProctoringLog> findByEventType(ProctoringLog.EventType eventType);
    List<ProctoringLog> findBySeverity(ProctoringLog.SeverityLevel severity);
    
    @Query("SELECT pl FROM ProctoringLog pl WHERE pl.examSession.id = :sessionId AND pl.severity IN :severities")
    List<ProctoringLog> findBySessionIdAndSeverityIn(Long sessionId, List<ProctoringLog.SeverityLevel> severities);
    
    @Query("SELECT pl FROM ProctoringLog pl WHERE pl.timestamp BETWEEN :start AND :end")
    List<ProctoringLog> findByTimestampBetween(LocalDateTime start, LocalDateTime end);
}