package com.examportal.dto;

import com.examportal.entity.ProctoringLog;
import jakarta.validation.constraints.NotNull;

public class ProctoringEventRequest {
    @NotNull
    private Long sessionId;
    
    @NotNull
    private ProctoringLog.EventType eventType;
    
    @NotNull
    private ProctoringLog.SeverityLevel severity;
    
    private String description;
    private String imageData; // Base64 encoded image
    private String metadata;

    public ProctoringEventRequest() {}

    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }

    public ProctoringLog.EventType getEventType() { return eventType; }
    public void setEventType(ProctoringLog.EventType eventType) { this.eventType = eventType; }

    public ProctoringLog.SeverityLevel getSeverity() { return severity; }
    public void setSeverity(ProctoringLog.SeverityLevel severity) { this.severity = severity; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageData() { return imageData; }
    public void setImageData(String imageData) { this.imageData = imageData; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }
}