package com.examportal.repository;

import com.examportal.entity.Exam;
import com.examportal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByInstructor(User instructor);
    List<Exam> findByActiveTrue();
    List<Exam> findByActiveTrueAndStartTimeBefore(LocalDateTime dateTime);
    List<Exam> findByActiveTrueAndEndTimeAfter(LocalDateTime dateTime);
    
    @Query("SELECT e FROM Exam e JOIN e.assignedStudents s WHERE s.id = :studentId AND e.active = true")
    List<Exam> findActiveExamsForStudent(Long studentId);
    
    @Query("SELECT e FROM Exam e WHERE e.active = true AND e.startTime <= :now AND e.endTime >= :now")
    List<Exam> findCurrentlyActiveExams(LocalDateTime now);
}