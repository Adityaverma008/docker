package com.examportal.controller;

import com.examportal.dto.ProctoringEventRequest;
import com.examportal.entity.ProctoringLog;
import com.examportal.service.ProctoringService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/proctoring")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ProctoringController {

    @Autowired
    private ProctoringService proctoringService;

    @PostMapping("/events")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR', 'STUDENT')")
    public ResponseEntity<ProctoringLog> logProctoringEvent(@Valid @RequestBody ProctoringEventRequest request) {
        ProctoringLog log = proctoringService.logProctoringEvent(request);
        return ResponseEntity.ok(log);
    }

    @PostMapping("/webcam-snapshot")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR', 'STUDENT')")
    public ResponseEntity<ProctoringLog> uploadWebcamSnapshot(
            @RequestParam Long sessionId,
            @RequestParam MultipartFile file,
            @RequestParam ProctoringLog.EventType eventType,
            @RequestParam ProctoringLog.SeverityLevel severity,
            @RequestParam(required = false) String description) throws IOException {
        
        ProctoringLog log = proctoringService.uploadWebcamSnapshot(sessionId, file, eventType, severity, description);
        return ResponseEntity.ok(log);
    }

    @GetMapping("/sessions/{sessionId}/logs")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
    public ResponseEntity<List<ProctoringLog>> getSessionLogs(@PathVariable Long sessionId) {
        List<ProctoringLog> logs = proctoringService.getSessionLogs(sessionId);
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/sessions/{sessionId}/violations")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
    public ResponseEntity<List<ProctoringLog>> getHighSeverityLogs(@PathVariable Long sessionId) {
        List<ProctoringLog> logs = proctoringService.getHighSeverityLogs(sessionId);
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/events/{eventType}")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
    public ResponseEntity<List<ProctoringLog>> getLogsByEventType(@PathVariable ProctoringLog.EventType eventType) {
        List<ProctoringLog> logs = proctoringService.getLogsByEventType(eventType);
        return ResponseEntity.ok(logs);
    }

    @GetMapping("/ai-analysis")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR', 'STUDENT')")
    public ResponseEntity<Map<String, Object>> analyzeImage(@RequestParam String imageData) {
        // Placeholder for AI analysis integration
        // This would integrate with external AI services for face detection, gaze tracking, etc.
        Map<String, Object> analysis = Map.of(
                "faceDetected", true,
                "multipleFaces", false,
                "gazeDirection", "center",
                "suspiciousActivity", false,
                "confidence", 0.95
        );
        return ResponseEntity.ok(analysis);
    }
}