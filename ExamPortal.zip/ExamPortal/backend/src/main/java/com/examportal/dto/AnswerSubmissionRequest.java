package com.examportal.dto;

import jakarta.validation.constraints.NotNull;

public class AnswerSubmissionRequest {
    @NotNull
    private Long questionId;
    
    private String answer;

    public AnswerSubmissionRequest() {}

    public AnswerSubmissionRequest(Long questionId, String answer) {
        this.questionId = questionId;
        this.answer = answer;
    }

    public Long getQuestionId() { return questionId; }
    public void setQuestionId(Long questionId) { this.questionId = questionId; }

    public String getAnswer() { return answer; }
    public void setAnswer(String answer) { this.answer = answer; }
}