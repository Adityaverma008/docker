package com.examportal.dto;

import com.examportal.entity.Question;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public class QuestionRequest {
    @NotBlank
    private String content;
    
    @NotNull
    private Question.QuestionType type;
    
    @NotNull
    private Question.DifficultyLevel difficulty;
    
    private String category;
    private String tags;
    private Integer points = 1;
    private List<String> options;
    
    @NotBlank
    private String correctAnswer;

    public QuestionRequest() {}

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Question.QuestionType getType() { return type; }
    public void setType(Question.QuestionType type) { this.type = type; }

    public Question.DifficultyLevel getDifficulty() { return difficulty; }
    public void setDifficulty(Question.DifficultyLevel difficulty) { this.difficulty = difficulty; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }

    public Integer getPoints() { return points; }
    public void setPoints(Integer points) { this.points = points; }

    public List<String> getOptions() { return options; }
    public void setOptions(List<String> options) { this.options = options; }

    public String getCorrectAnswer() { return correctAnswer; }
    public void setCorrectAnswer(String correctAnswer) { this.correctAnswer = correctAnswer; }
}