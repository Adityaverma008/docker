package com.examportal.entity;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "proctoring_logs")
@EntityListeners(AuditingEntityListener.class)
public class ProctoringLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_session_id")
    private ExamSession examSession;

    @Enumerated(EnumType.STRING)
    private EventType eventType;

    @Enumerated(EnumType.STRING)
    private SeverityLevel severity;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String imageUrl; // For storing webcam snapshots
    private String metadata; // JSON string for additional data

    @CreatedDate
    private LocalDateTime timestamp;

    public enum EventType {
        FACE_NOT_DETECTED, MULTIPLE_FACES, GAZE_AWAY, TAB_SWITCH, 
        WINDOW_FOCUS_LOST, SUSPICIOUS_MOVEMENT, AUDIO_DETECTED, 
        SCREEN_SHARE_DETECTED, EXAM_START, EXAM_END, VIOLATION
    }

    public enum SeverityLevel {
        LOW, MEDIUM, HIGH, CRITICAL
    }

    // Constructors
    public ProctoringLog() {}

    public ProctoringLog(ExamSession examSession, EventType eventType, SeverityLevel severity, String description) {
        this.examSession = examSession;
        this.eventType = eventType;
        this.severity = severity;
        this.description = description;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public ExamSession getExamSession() { return examSession; }
    public void setExamSession(ExamSession examSession) { this.examSession = examSession; }

    public EventType getEventType() { return eventType; }
    public void setEventType(EventType eventType) { this.eventType = eventType; }

    public SeverityLevel getSeverity() { return severity; }
    public void setSeverity(SeverityLevel severity) { this.severity = severity; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}