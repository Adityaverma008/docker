package com.examportal.repository;

import com.examportal.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findByUserId(Long userId);
    List<AuditLog> findByUsername(String username);
    List<AuditLog> findByActionType(AuditLog.ActionType actionType);
    List<AuditLog> findByIpAddress(String ipAddress);
    
    @Query("SELECT al FROM AuditLog al WHERE al.timestamp BETWEEN :start AND :end")
    List<AuditLog> findByTimestampBetween(LocalDateTime start, LocalDateTime end);
    
    @Query("SELECT al FROM AuditLog al WHERE al.userId = :userId AND al.actionType = :actionType")
    List<AuditLog> findByUserIdAndActionType(Long userId, AuditLog.ActionType actionType);
}