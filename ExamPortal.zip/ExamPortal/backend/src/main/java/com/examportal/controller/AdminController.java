package com.examportal.controller;

import com.examportal.entity.User;
import com.examportal.service.AuditService;
import com.examportal.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private AuditService auditService;

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/users/role/{role}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable User.Role role) {
        List<User> users = userService.getUsersByRole(role);
        return ResponseEntity.ok(users);
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        User updatedUser = userService.updateUser(id, userDetails);
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<?> getAuditLogs(@RequestParam(required = false) Long userId,
                                        @RequestParam(required = false) String actionType,
                                        @RequestParam(required = false) String startDate,
                                        @RequestParam(required = false) String endDate) {
        if (userId != null) {
            return ResponseEntity.ok(auditService.getAuditLogsByUser(userId));
        }
        
        if (actionType != null) {
            return ResponseEntity.ok(auditService.getAuditLogsByActionType(
                    com.examportal.entity.AuditLog.ActionType.valueOf(actionType)));
        }
        
        if (startDate != null && endDate != null) {
            LocalDateTime start = LocalDateTime.parse(startDate);
            LocalDateTime end = LocalDateTime.parse(endDate);
            return ResponseEntity.ok(auditService.getAuditLogsByDateRange(start, end));
        }
        
        return ResponseEntity.badRequest().body(Map.of("message", "Please provide valid query parameters"));
    }

    @GetMapping("/dashboard/stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        List<User> allUsers = userService.getAllUsers();
        long totalUsers = allUsers.size();
        long adminCount = allUsers.stream().filter(u -> u.getRole() == User.Role.ADMIN).count();
        long instructorCount = allUsers.stream().filter(u -> u.getRole() == User.Role.INSTRUCTOR).count();
        long studentCount = allUsers.stream().filter(u -> u.getRole() == User.Role.STUDENT).count();

        Map<String, Object> stats = Map.of(
                "totalUsers", totalUsers,
                "adminCount", adminCount,
                "instructorCount", instructorCount,
                "studentCount", studentCount
        );

        return ResponseEntity.ok(stats);
    }
}