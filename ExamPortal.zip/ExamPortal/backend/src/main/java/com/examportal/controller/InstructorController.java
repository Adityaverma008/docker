package com.examportal.controller;

import com.examportal.dto.ExamRequest;
import com.examportal.dto.QuestionRequest;
import com.examportal.entity.Exam;
import com.examportal.entity.Question;
import com.examportal.entity.User;
import com.examportal.security.UserPrincipal;
import com.examportal.service.ExamService;
import com.examportal.service.QuestionService;
import com.examportal.service.ReportService;
import com.examportal.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/instructor")
@PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class InstructorController {

    @Autowired
    private ExamService examService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserService userService;

    @Autowired
    private ReportService reportService;

    // Question Management
    @PostMapping("/questions")
    public ResponseEntity<Question> createQuestion(@Valid @RequestBody QuestionRequest request) {
        Question question = questionService.createQuestion(request);
        return ResponseEntity.ok(question);
    }

    @GetMapping("/questions")
    public ResponseEntity<List<Question>> getAllQuestions() {
        List<Question> questions = questionService.getAllQuestions();
        return ResponseEntity.ok(questions);
    }

    @GetMapping("/questions/{id}")
    public ResponseEntity<Question> getQuestion(@PathVariable Long id) {
        Question question = questionService.getQuestionById(id);
        return ResponseEntity.ok(question);
    }

    @PutMapping("/questions/{id}")
    public ResponseEntity<Question> updateQuestion(@PathVariable Long id, 
                                                 @Valid @RequestBody QuestionRequest request) {
        Question question = questionService.updateQuestion(id, request);
        return ResponseEntity.ok(question);
    }

    @DeleteMapping("/questions/{id}")
    public ResponseEntity<?> deleteQuestion(@PathVariable Long id) {
        questionService.deleteQuestion(id);
        return ResponseEntity.ok(Map.of("message", "Question deleted successfully"));
    }

    @GetMapping("/questions/categories")
    public ResponseEntity<List<String>> getQuestionCategories() {
        List<String> categories = questionService.getAllCategories();
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/questions/category/{category}")
    public ResponseEntity<List<Question>> getQuestionsByCategory(@PathVariable String category) {
        List<Question> questions = questionService.getQuestionsByCategory(category);
        return ResponseEntity.ok(questions);
    }

    // Exam Management
    @PostMapping("/exams")
    public ResponseEntity<Exam> createExam(@Valid @RequestBody ExamRequest request, 
                                         Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User instructor = userService.getUserByUsername(userPrincipal.getUsername());
        Exam exam = examService.createExam(request, instructor);
        return ResponseEntity.ok(exam);
    }

    @GetMapping("/exams")
    public ResponseEntity<List<Exam>> getMyExams(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User instructor = userService.getUserByUsername(userPrincipal.getUsername());
        List<Exam> exams = examService.getExamsByInstructor(instructor);
        return ResponseEntity.ok(exams);
    }

    @GetMapping("/exams/{id}")
    public ResponseEntity<Exam> getExam(@PathVariable Long id) {
        Exam exam = examService.getExamById(id);
        return ResponseEntity.ok(exam);
    }

    @PutMapping("/exams/{id}")
    public ResponseEntity<Exam> updateExam(@PathVariable Long id, 
                                         @Valid @RequestBody ExamRequest request) {
        Exam exam = examService.updateExam(id, request);
        return ResponseEntity.ok(exam);
    }

    @DeleteMapping("/exams/{id}")
    public ResponseEntity<?> deleteExam(@PathVariable Long id) {
        examService.deleteExam(id);
        return ResponseEntity.ok(Map.of("message", "Exam deleted successfully"));
    }

    @PostMapping("/exams/{id}/assign-students")
    public ResponseEntity<Exam> assignStudentsToExam(@PathVariable Long id, 
                                                    @RequestBody List<Long> studentIds) {
        Exam exam = examService.assignStudentsToExam(id, studentIds);
        return ResponseEntity.ok(exam);
    }

    @GetMapping("/students")
    public ResponseEntity<List<User>> getAllStudents() {
        List<User> students = userService.getUsersByRole(User.Role.STUDENT);
        return ResponseEntity.ok(students);
    }

    // Reports
    @GetMapping("/exams/{id}/results/csv")
    public ResponseEntity<String> getExamResultsCSV(@PathVariable Long id) {
        String csv = reportService.generateExamResultsCSV(id);
        return ResponseEntity.ok()
                .header("Content-Type", "text/csv")
                .header("Content-Disposition", "attachment; filename=exam_results.csv")
                .body(csv);
    }

    @GetMapping("/exams/{id}/analytics")
    public ResponseEntity<Map<String, Object>> getExamAnalytics(@PathVariable Long id) {
        Map<String, Object> analytics = reportService.generateExamAnalytics(id);
        return ResponseEntity.ok(analytics);
    }
}