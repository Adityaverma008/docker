package com.examportal.service;

import com.examportal.dto.AnswerSubmissionRequest;
import com.examportal.entity.*;
import com.examportal.exception.ResourceNotFoundException;
import com.examportal.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ExamSessionService {
    @Autowired
    private ExamSessionRepository examSessionRepository;

    @Autowired
    private StudentAnswerRepository studentAnswerRepository;

    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private AuditService auditService;

    @Transactional
    public ExamSession startExamSession(Long examId, Long studentId, String ipAddress, String userAgent) {
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + examId));
        
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));

        // Check if session already exists
        ExamSession existingSession = examSessionRepository.findByExamAndStudent(exam, student).orElse(null);
        if (existingSession != null && existingSession.getStatus() != ExamSession.SessionStatus.COMPLETED) {
            throw new RuntimeException("Exam session already exists for this student");
        }

        ExamSession session = new ExamSession(exam, student);
        session.setStartTime(LocalDateTime.now());
        session.setStatus(ExamSession.SessionStatus.IN_PROGRESS);
        session.setIpAddress(ipAddress);
        session.setUserAgent(userAgent);

        ExamSession savedSession = examSessionRepository.save(session);
        auditService.logUserAction(studentId, student.getUsername(), "Exam started: " + exam.getTitle(), "EXAM_START");
        return savedSession;
    }

    public ExamSession getSessionById(Long sessionId) {
        return examSessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam session not found: " + sessionId));
    }

    public List<ExamSession> getSessionsByStudent(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));
        return examSessionRepository.findByStudent(student);
    }

    @Transactional
    public StudentAnswer submitAnswer(Long sessionId, AnswerSubmissionRequest request) {
        ExamSession session = getSessionById(sessionId);
        Question question = questionRepository.findById(request.getQuestionId())
                .orElseThrow(() -> new ResourceNotFoundException("Question not found: " + request.getQuestionId()));

        // Check if answer already exists
        StudentAnswer existingAnswer = studentAnswerRepository
                .findByExamSessionAndQuestionId(session, request.getQuestionId()).orElse(null);

        StudentAnswer answer;
        if (existingAnswer != null) {
            answer = existingAnswer;
            answer.setAnswer(request.getAnswer());
        } else {
            answer = new StudentAnswer(session, question, request.getAnswer());
        }

        // Check if answer is correct
        boolean isCorrect = checkAnswer(question, request.getAnswer());
        answer.setCorrect(isCorrect);
        answer.setPointsEarned(isCorrect ? question.getPoints() : 0);

        return studentAnswerRepository.save(answer);
    }

    @Transactional
    public ExamSession submitExam(Long sessionId) {
        ExamSession session = getSessionById(sessionId);
        session.setStatus(ExamSession.SessionStatus.COMPLETED);
        session.setSubmittedAt(LocalDateTime.now());
        session.setEndTime(LocalDateTime.now());

        // Calculate score
        List<StudentAnswer> answers = studentAnswerRepository.findByExamSession(session);
        int totalScore = answers.stream().mapToInt(StudentAnswer::getPointsEarned).sum();
        session.setScore(totalScore);

        if (session.getExam().getTotalMarks() > 0) {
            double percentage = (double) totalScore / session.getExam().getTotalMarks() * 100;
            session.setPercentage(percentage);
        }

        ExamSession savedSession = examSessionRepository.save(session);
        auditService.logUserAction(session.getStudent().getId(), session.getStudent().getUsername(), 
                "Exam submitted: " + session.getExam().getTitle(), "EXAM_SUBMIT");
        return savedSession;
    }

    public ExamSession terminateSession(Long sessionId, String reason) {
        ExamSession session = getSessionById(sessionId);
        session.setStatus(ExamSession.SessionStatus.TERMINATED);
        session.setEndTime(LocalDateTime.now());
        
        ExamSession savedSession = examSessionRepository.save(session);
        auditService.logUserAction(session.getStudent().getId(), session.getStudent().getUsername(), 
                "Exam terminated: " + reason, "VIOLATION");
        return savedSession;
    }

    private boolean checkAnswer(Question question, String studentAnswer) {
        if (studentAnswer == null || question.getCorrectAnswer() == null) {
            return false;
        }
        
        return question.getCorrectAnswer().trim().equalsIgnoreCase(studentAnswer.trim());
    }
}