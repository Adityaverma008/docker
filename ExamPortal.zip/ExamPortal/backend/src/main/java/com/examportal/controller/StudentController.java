package com.examportal.controller;

import com.examportal.dto.AnswerSubmissionRequest;
import com.examportal.entity.Exam;
import com.examportal.entity.ExamSession;
import com.examportal.entity.StudentAnswer;
import com.examportal.entity.User;
import com.examportal.security.UserPrincipal;
import com.examportal.service.ExamService;
import com.examportal.service.ExamSessionService;
import com.examportal.service.ReportService;
import com.examportal.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/student")
@PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR', 'STUDENT')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class StudentController {

    @Autowired
    private ExamService examService;

    @Autowired
    private ExamSessionService examSessionService;

    @Autowired
    private UserService userService;

    @Autowired
    private ReportService reportService;

    @GetMapping("/exams")
    public ResponseEntity<List<Exam>> getMyExams(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        List<Exam> exams = examService.getActiveExamsForStudent(userPrincipal.getId());
        return ResponseEntity.ok(exams);
    }

    @GetMapping("/exams/{id}")
    public ResponseEntity<Exam> getExam(@PathVariable Long id) {
        Exam exam = examService.getExamById(id);
        return ResponseEntity.ok(exam);
    }

    @PostMapping("/exams/{examId}/start")
    public ResponseEntity<ExamSession> startExam(@PathVariable Long examId, 
                                               Authentication authentication,
                                               HttpServletRequest request) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        String ipAddress = getClientIpAddress(request);
        String userAgent = request.getHeader("User-Agent");
        
        ExamSession session = examSessionService.startExamSession(examId, userPrincipal.getId(), 
                ipAddress, userAgent);
        return ResponseEntity.ok(session);
    }

    @PostMapping("/sessions/{sessionId}/submit-answer")
    public ResponseEntity<StudentAnswer> submitAnswer(@PathVariable Long sessionId,
                                                    @Valid @RequestBody AnswerSubmissionRequest request) {
        StudentAnswer answer = examSessionService.submitAnswer(sessionId, request);
        return ResponseEntity.ok(answer);
    }

    @PostMapping("/sessions/{sessionId}/submit")
    public ResponseEntity<ExamSession> submitExam(@PathVariable Long sessionId) {
        ExamSession session = examSessionService.submitExam(sessionId);
        return ResponseEntity.ok(session);
    }

    @GetMapping("/sessions/{sessionId}")
    public ResponseEntity<ExamSession> getSession(@PathVariable Long sessionId) {
        ExamSession session = examSessionService.getSessionById(sessionId);
        return ResponseEntity.ok(session);
    }

    @GetMapping("/sessions")
    public ResponseEntity<List<ExamSession>> getMySessions(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        List<ExamSession> sessions = examSessionService.getSessionsByStudent(userPrincipal.getId());
        return ResponseEntity.ok(sessions);
    }

    @GetMapping("/performance")
    public ResponseEntity<Map<String, Object>> getMyPerformance(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        Map<String, Object> performance = reportService.generateStudentPerformanceReport(userPrincipal.getId());
        return ResponseEntity.ok(performance);
    }

    @GetMapping("/profile")
    public ResponseEntity<User> getProfile(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User user = userService.getUserById(userPrincipal.getId());
        return ResponseEntity.ok(user);
    }

    @PutMapping("/profile")
    public ResponseEntity<User> updateProfile(@RequestBody User userDetails, 
                                            Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User updatedUser = userService.updateUser(userPrincipal.getId(), userDetails);
        return ResponseEntity.ok(updatedUser);
    }

    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedForHeader = request.getHeader("X-Forwarded-For");
        if (xForwardedForHeader == null) {
            return request.getRemoteAddr();
        } else {
            return xForwardedForHeader.split(",")[0];
        }
    }
}