package com.examportal.repository;

import com.examportal.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByCategory(String category);
    List<Question> findByType(Question.QuestionType type);
    List<Question> findByDifficulty(Question.DifficultyLevel difficulty);
    List<Question> findByCategoryAndType(String category, Question.QuestionType type);
    List<Question> findByCategoryAndDifficulty(String category, Question.DifficultyLevel difficulty);
    
    @Query("SELECT DISTINCT q.category FROM Question q")
    List<String> findAllCategories();
    
    @Query("SELECT q FROM Question q WHERE q.tags LIKE %:tag%")
    List<Question> findByTag(String tag);
}