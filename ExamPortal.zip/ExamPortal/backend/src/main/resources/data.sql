-- Default Admin User (password: Aditya@1234)
INSERT INTO users (username, email, password, first_name, last_name, role, enabled, created_at, updated_at) 
VALUES ('Addy', 'aditya@examportal.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Aditya', 'Verma', 'ADMIN', true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Insert sample questions
INSERT INTO questions (content, type, difficulty, category, tags, points, correct_answer, created_at, updated_at) 
VALUES 
('What is the capital of France?', 'MCQ', 'EASY', 'Geography', 'capitals,europe', 1, 'Paris', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Explain the concept of Object-Oriented Programming.', 'SHORT_ANSWER', 'MEDIUM', 'Programming', 'oop,concepts', 5, 'Object-Oriented Programming is a programming paradigm based on objects and classes', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('What is 2 + 2?', 'MCQ', 'EASY', 'Mathematics', 'arithmetic,basic', 1, '4', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('What is the derivative of x²?', 'SHORT_ANSWER', 'MEDIUM', 'Mathematics', 'calculus,derivatives', 3, '2x', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Which programming language is used for Android development?', 'MCQ', 'MEDIUM', 'Programming', 'android,mobile', 2, 'Java', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('The Earth is round.', 'TRUE_FALSE', 'EASY', 'Geography', 'earth,basic', 1, 'True', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Insert options for MCQ questions
INSERT INTO question_options (question_id, option_text) 
VALUES 
(1, 'London'),
(1, 'Berlin'), 
(1, 'Paris'),
(1, 'Madrid'),
(3, '3'),
(3, '4'),
(3, '5'),
(3, '6'),
(5, 'Java'),
(5, 'Python'),
(5, 'JavaScript'),
(5, 'C++'),
(6, 'True'),
(6, 'False');

-- Insert sample exams
INSERT INTO exams (title, description, duration, total_marks, start_time, end_time, randomize_questions, active, instructor_id, created_at, updated_at)
VALUES 
('Mathematics Final Exam', 'Comprehensive mathematics exam covering algebra and calculus', 120, 100, CURRENT_TIMESTAMP, DATEADD('DAY', 7, CURRENT_TIMESTAMP), false, true, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Programming Basics Quiz', 'Quick assessment on programming fundamentals', 45, 50, CURRENT_TIMESTAMP, DATEADD('DAY', 3, CURRENT_TIMESTAMP), true, true, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Geography Knowledge Test', 'Test your knowledge of world geography', 60, 75, CURRENT_TIMESTAMP, DATEADD('DAY', 5, CURRENT_TIMESTAMP), false, true, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Link questions to exams
INSERT INTO exam_questions (exam_id, question_id)
VALUES 
(1, 3), (1, 4),
(2, 2), (2, 5),
(3, 1), (3, 6);